# Instruções de Implantação via FTP

Este guia detalha como fazer o upload do seu sistema de agendamento para um servidor web usando FTP.

## 📦 Arquivo do Projeto

O projeto completo está compactado no arquivo:
`agendamento_multi_db_completo_atualizado.zip`

## 🔑 Credenciais FTP Fornecidas

-   **Host FTP Principal:** `ftp.examesneurologicos.com.br`
-   **Host FTP Alternativo:** `ftp.web232.uni5.net`
-   **Usuário FTP:** `examesneurologicos`
-   **Senha FTP:** `FFet63gehj788`
-   **Caminho Físico no Servidor:** `/home/examesneurologicos`

## 📝 Passos para Implantação

Siga estes passos para fazer o upload e configurar seu site:

### Passo 1: Descompactar o Projeto

Primeiro, descompacte o arquivo `agendamento_multi_db_completo_atualizado.zip` no seu computador local. Isso criará uma pasta com todos os arquivos do sistema (incluindo `admin.html`, `api.php`, `install.php`, `index.html`, `DatabaseManager.php`, `config.php`, etc.).

### Passo 2: Conectar ao Servidor FTP

Utilize um cliente FTP (como FileZilla, WinSCP, Cyberduck, ou o cliente FTP integrado do seu sistema operacional) para se conectar ao seu servidor web. Use as credenciais fornecidas:

-   **Host:** `ftp.examesneurologicos.com.br` (ou `ftp.web232.uni5.net` se o principal não funcionar)
-   **Usuário:** `examesneurologicos`
-   **Senha:** `FFet63gehj788`
-   **Porta:** A porta padrão para FTP é 21. Se o seu cliente FTP não se conectar, tente especificar a porta 21.

### Passo 3: Fazer o Upload dos Arquivos

Após conectar, navegue até o diretório de destino no servidor. O caminho físico fornecido é `/home/examesneurologicos`. Este é o diretório onde os arquivos do seu site devem ser colocados para serem acessíveis via web.

**Importante:** Faça o upload de **todos os arquivos e pastas** que você descompactou no Passo 1 para este diretório no servidor. Certifique-se de que a estrutura de pastas seja mantida.

### Passo 4: Configurar Permissões (se necessário)

Em alguns servidores, pode ser necessário ajustar as permissões de arquivos e pastas para que o PHP possa ler e escrever. Geralmente, as permissões são:

-   **Pastas:** `755` (rwxr-xr-x)
-   **Arquivos:** `644` (rw-r--r--)

O arquivo `config.php` será criado pelo `install.php`, então o diretório onde ele será salvo (o mesmo onde estão os outros arquivos) precisa ter permissão de escrita para o usuário do servidor web (geralmente `755` para a pasta já é suficiente).

### Passo 5: Executar a Instalação Online

Após o upload de todos os arquivos, abra seu navegador e acesse a página de instalação:

`http://seusite.com/install.php`

(Substitua `seusite.com` pelo seu domínio ou endereço IP do servidor)

Na página de instalação:

1.  **Selecione o tipo de banco de dados** (MySQL, SQLite, PostgreSQL, Firebird).
2.  **Preencha os dados de conexão** com o seu banco de dados. As credenciais de exemplo já estarão pré-preenchidas.
3.  Clique em **"Instalar Sistema"**. O script irá testar a conexão, criar as tabelas necessárias e gerar o arquivo `config.php`.

### Passo 6: Acessar o Sistema

Após a instalação bem-sucedida, você pode acessar:

-   **Página de Agendamento:** `http://seusite.com/index.html`
-   **Painel Administrativo:** `http://seusite.com/admin.html`

## ⚠️ Observações Importantes

-   Certifique-se de que seu servidor web possui o PHP 7.4 ou superior instalado e as extensões PHP necessárias para o tipo de banco de dados que você escolher (ex: `php-pdo`, `php-mysql`, `php-sqlite3`, `php-pgsql`, `php-interbase` para Firebird).
-   O arquivo `agendamentos.db` (para SQLite) será criado automaticamente se você selecionar SQLite durante a instalação.
-   As configurações de exames e horários fixos são definidas no `config.php`. Para personalizá-las, você pode editar este arquivo diretamente após a instalação ou implementar uma interface administrativa para isso.

Se tiver qualquer problema durante a implantação, verifique os logs do seu servidor web para mensagens de erro mais detalhadas.

