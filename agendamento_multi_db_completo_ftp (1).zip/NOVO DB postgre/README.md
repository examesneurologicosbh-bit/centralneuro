# Sistema de Agendamento EEG - Versão Melhorada

## Melhorias Implementadas

### 1. Banco de Dados SQLite
- Substituição do arquivo de texto por banco de dados SQLite
- Estrutura robusta com tabela `agendamentos`
- Constraint UNIQUE para prevenir horários duplos
- Armazenamento completo dos dados do paciente

### 2. API REST
- Endpoint unificado (`api.php`) para todas as operações
- Suporte a CORS para integração frontend/backend
- Validação e sanitização completa dos dados
- Tratamento de erros robusto

### 3. Frontend Aprimorado
- Melhor tratamento de erros e feedback visual
- Estados de loading durante operações
- Mensagens de sucesso e erro
- Prevenção de duplo clique durante agendamento

### 4. Prevenção de Horários Duplos
- Verificação no banco de dados com constraint UNIQUE
- Tratamento de conflitos com mensagens específicas
- Atualização automática da lista de horários disponíveis

### 5. Página de Administração
- Visualização de todos os agendamentos
- Estatísticas em tempo real
- Interface responsiva para desktop e mobile

## Estrutura de Arquivos

```
agendamento_melhorado/
├── index.html          # Frontend principal
├── api.php            # API REST
├── database.php       # Classe de banco de dados
├── admin.html         # Página de administração
├── migrate_data.php   # Script de migração
├── README.md          # Esta documentação
└── agendamentos.db    # Banco SQLite (criado automaticamente)
```

## Instalação

1. Copie todos os arquivos para o servidor web
2. Certifique-se de que o PHP tem permissões de escrita no diretório
3. Execute o script de migração (opcional):
   ```bash
   php migrate_data.php
   ```

## Uso

### Frontend Principal
- Acesse `index.html` para fazer agendamentos
- Todos os campos são obrigatórios
- Sistema previne horários duplos automaticamente

### Administração
- Acesse `admin.html` para visualizar agendamentos
- Estatísticas atualizadas em tempo real
- Lista completa de todos os agendamentos

## API Endpoints

### GET api.php?action=horarios-ocupados
Retorna lista de horários já agendados

### GET api.php?action=agendamentos
Retorna todos os agendamentos (para administração)

### POST api.php?action=agendar
Cria novo agendamento
```json
{
  "nomePaciente": "Nome do Paciente",
  "anoNascimento": 1990,
  "tipoEeg": "EEG Rotina - R$120,00",
  "dataAgendamento": "16/08/2025",
  "horario": "14:00"
}
```

## Banco de Dados

### Tabela: agendamentos
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `nome_paciente` (TEXT NOT NULL)
- `ano_nascimento` (INTEGER NOT NULL)
- `tipo_eeg` (TEXT NOT NULL)
- `data_agendamento` (TEXT NOT NULL)
- `horario` (TEXT NOT NULL)
- `data_criacao` (DATETIME DEFAULT CURRENT_TIMESTAMP)
- UNIQUE constraint em (`data_agendamento`, `horario`)

## Segurança

- Validação completa de todos os dados de entrada
- Sanitização de dados antes do armazenamento
- Prepared statements para prevenir SQL injection
- Headers CORS configurados adequadamente

## Compatibilidade

- PHP 7.0+
- SQLite (incluído no PHP por padrão)
- Navegadores modernos com suporte a ES6
- Responsivo para desktop e mobile

