<?php
// Start session to store temporary installation data
session_start();

// Initialize variables
$error = '';
$success = '';
$step = isset($_POST['step']) ? (int)$_POST['step'] : 1;

// Database configuration template
function generateConfigFile($host, $db_name, $username, $password) {
    return "<?php
class JConfig {
    public \$host = '$host';
    public \$db = '$db_name';
    public \$user = '$username';
    public \$password = '$password';
    public \$dbtype = 'pgsql';
    public \$dbprefix = 'fkumx_';
    public \$MetaAuthor = '0';
    public \$MetaDesc = 'Central de Exames Neurológicos';
    public \$MetaKeys = 'Central de Exames Neurológicos';
    public \$MetaRights = '';
    public \$MetaTitle = '1';
    public \$MetaVersion = '0';
    public \$access = '1';
    public \$cache_handler = 'file';
    public \$cachetime = '30';
    public \$caching = '1';
    public \$captcha = 'recaptcha';
    public \$cookie_domain = '';
    public \$cookie_path = '';
    public \$debug = '0';
    public \$debug_lang = '0';
    public \$display_offline_message = '1';
    public \$editor = 'none';
    public \$error_reporting = 'none';
    public \$feed_email = 'none';
    public \$feed_limit = '10';
    public \$force_ssl = '2';
    public \$fromname = 'Central de Exames Neurológicos';
    public \$ftp_enable = '0';
    public \$ftp_host = '';
    public \$ftp_pass = '';
    public \$ftp_port = '21';
    public \$ftp_root = '';
    public \$ftp_user = '';
    public \$gzip = '1';
    public \$helpurl = 'https://help.joomla.org/proxy?keyref=Help{major}{minor}:{keyref}&lang={langcode}';
    public \$lifetime = '999';
    public \$robots = '';
    public \$secret = 'HbHzA5e5YKQt0PD34wYXgBwWH2sW3lUe';
    public \$sef = '1';
    public \$sef_rewrite = '1';
    public \$sef_suffix = '0';
    public \$sendmail = '/usr/sbin/sendmail';
    public \$session_handler = 'none';
    public \$sitename = 'Central de Exames Neurológicos';
    public \$sitename_pagetitles = '0';
    public \$smtpauth = '1';
    public \$smtphost = 'smtpi.uni5.net';
    public \$smtppass = 'masquenada12@3';
    public \$smtpport = '587';
    public \$smtpsecure = 'tls';
    public \$smtpuser = 'contato@examesneurologicos.com.br';
    public \$tmp_path = '/tmp';
    public \$unicodeslugs = '0';
    public \$mailonline = '0';
    public \$memcached_persist = '1';
    public \$memcached_compress = '0';
    public \$memcached_server_host = 'localhost';
    public \$memcached_server_port = '11211';
    public \$redis_persist = '1';
    public \$redis_server_host = 'localhost';
    public \$redis_server_port = '6379';
    public \$redis_server_auth = '';
    public \$redis_server_db = '0';
    public \$proxy_enable = '0';
    public \$proxy_host = '';
    public \$proxy_port = '';
    public \$proxy_user = '';
    public \$proxy_pass = '';
    public \$massmailoff = '1';
    public \$session_memcache_server_host = 'localhost';
    public \$session_memcache_server_port = '11211';
    public \$session_memcached_server_host = 'localhost';
    public \$session_memcached_server_port = '11211';
    public \$frontediting = '2';
    public \$asset_id = '1';
    public \$cache_platformprefix = '1';
    public \$memcache_persist = '1';
    public \$memcache_compress = '0';
    public \$memcache_server_host = 'localhost';
    public \$memcache_server_port = '11211';
    public \$offset = 'UTC';
    public \$mailfrom = '';
    public \$mailer = 'mail';
    public \$offline = '0';
    public \$offline_message = '';
    public \$offline_image = '';
    public \$list_limit = '20';
    public \$log_path = '/tmp';
    public \$debug_lang_const = '1';
    public \$behind_loadbalancer = '0';
    public \$replyto = '';
    public \$replytoname = '';
    public \$session_redis_persist = '1';
    public \$session_redis_server_host = 'localhost';
    public \$session_redis_server_port = '6379';
    public \$session_redis_server_db = '0';
    public \$shared_session = '0';
}
";
}

function generateDatabaseFile($host, $db_name, $username, $password) {
    return "<?php
class Database {
    private \$pdo;
    private \$host = '$host';
    private \$db_name = '$db_name';
    private \$username = '$username';
    private \$password = '$password';

    public function __construct() {
        \$dsn = \"pgsql:host={\$this->host};dbname={\$this->db_name}\";
        try {
            \$this->pdo = new PDO(\$dsn, \$this->username, \$this->password);
            \$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            \$this->createTables();
        } catch (PDOException \$e) {
            die('Erro na conexão com o banco de dados: ' . \$e->getMessage());
        }
    }
    
    private function createTables() {
        \$sql = \"CREATE TABLE IF NOT EXISTS agendamentos (
            id SERIAL PRIMARY KEY,
            nome_paciente VARCHAR(255) NOT NULL,
            ano_nascimento INTEGER NOT NULL,
            tipo_eeg VARCHAR(255) NOT NULL,
            data_agendamento VARCHAR(10) NOT NULL,
            horario VARCHAR(5) NOT NULL,
            dia_semana VARCHAR(20) NOT NULL,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT unique_data_horario UNIQUE (data_agendamento, horario)
        )\";
        
        \$this->pdo->exec(\$sql);
        
        // Check and add dia_semana column if missing
        \$checkColumn = \$this->pdo->query(\"SELECT column_name FROM information_schema.columns WHERE table_name = 'agendamentos' AND column_name = 'dia_semana'\");
        if (\$checkColumn->rowCount() == 0) {
            \$alterSql = \"ALTER TABLE agendamentos ADD COLUMN dia_semana VARCHAR(20) NOT NULL\";
            \$this->pdo->exec(\$alterSql);
            
            // Update existing records with dia_semana
            \$updateSql = \"UPDATE agendamentos SET dia_semana = CASE 
                WHEN data_agendamento ~ '^[0-3][0-9]/[0-1][0-9]/[0-9]{4}\$' THEN 
                    to_char(to_date(data_agendamento, 'DD/MM/YYYY'), 'Day')
                ELSE 'Unknown'
            END\";
            \$this->pdo->exec(\$updateSql);
        }
    }
    
    public function getConnection() {
        return \$this->pdo;
    }
    
    public function getHorariosOcupados() {
        \$stmt = \$this->pdo->prepare(\"SELECT data_agendamento, horario FROM agendamentos\");
        \$stmt->execute();
        \$result = \$stmt->fetchAll(PDO::FETCH_ASSOC);
        
        \$horarios = [];
        foreach (\$result as \$row) {
            \$horarios[] = \$row['data_agendamento'] . ' ' . \$row['horario'];
        }
        
        return \$horarios;
    }
    
    public function getHorariosOcupadosPorDia(\$dataAgendamento) {
        \$stmt = \$this->pdo->prepare(\"SELECT horario FROM agendamentos WHERE data_agendamento = ?\");
        \$stmt->execute([\$dataAgendamento]);
        \$result = \$stmt->fetchAll(PDO::FETCH_ASSOC);
        
        \$horarios = [];
        foreach (\$result as \$row) {
            \$horarios[] = \$row['horario'];
        }
        
        return \$horarios;
    }
    
    public function getHorariosDisponiveis(\$dataAgendamento, \$diaSemana) {
        \$horariosFixos = [
            'Monday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00'],
            'Tuesday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00'],
            'Wednesday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00'],
            'Thursday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00'],
            'Friday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00']
        ];
        
        if (!isset(\$horariosFixos[\$diaSemana])) {
            return [];
        }
        
        \$horariosOcupados = \$this->getHorariosOcupadosPorDia(\$dataAgendamento);
        \$horariosDisponiveis = array_diff(\$horariosFixos[\$diaSemana], \$horariosOcupados);
        
        return array_values(\$horariosDisponiveis);
    }
    
    public function agendarHorario(\$nomePaciente, \$anoNascimento, \$tipoEeg, \$dataAgendamento, \$horario, \$diaSemana = null) {
        try {
            if (\$diaSemana === null) {
                \$dateParts = explode('/', \$dataAgendamento);
                if (count(\$dateParts) === 3) {
                    \$dateObj = DateTime::createFromFormat('d/m/Y', \$dataAgendamento);
                    if (\$dateObj) {
                        \$diaSemana = \$dateObj->format('l');
                    }
                }
            }
            
            \$stmt = \$this->pdo->prepare(\"INSERT INTO agendamentos (nome_paciente, ano_nascimento, tipo_eeg, data_agendamento, horario, dia_semana) VALUES (?, ?, ?, ?, ?, ?)\");
            \$stmt->execute([\$nomePaciente, \$anoNascimento, \$tipoEeg, \$dataAgendamento, \$horario, \$diaSemana]);
            return ['success' => true, 'message' => 'Agendamento realizado com sucesso'];
        } catch (PDOException \$e) {
            if (strpos(\$e->getMessage(), 'unique_data_horario') !== false) {
                return ['success' => false, 'message' => 'Este horário já está ocupado'];
            }
            return ['success' => false, 'message' => 'Erro ao realizar agendamento: ' . \$e->getMessage()];
        }
    }
    
    public function getAgendamentos() {
        \$stmt = \$this->pdo->prepare(\"SELECT * FROM agendamentos ORDER BY data_agendamento, horario\");
        \$stmt->execute();
        return \$stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function verificarDisponibilidade(\$dataAgendamento, \$horario) {
        \$stmt = \$this->pdo->prepare(\"SELECT COUNT(*) as count FROM agendamentos WHERE data_agendamento = ? AND horario = ?\");
        \$stmt->execute([\$dataAgendamento, \$horario]);
        \$result = \$stmt->fetch(PDO::FETCH_ASSOC);
        
        return \$result['count'] == 0;
    }
}
?>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 1) {
    // Step 1: Test database connection
    $host = trim($_POST['host'] ?? '');
    $db_name = trim($_POST['db_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($host) || empty($db_name) || empty($username)) {
        $error = 'Por favor, preencha todos os campos obrigatórios.';
    } else {
        try {
            $dsn = "pgsql:host=$host;dbname=$db_name";
            $pdo = new PDO($dsn, $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Store credentials in session for next step
            $_SESSION['db_credentials'] = [
                'host' => $host,
                'db_name' => $db_name,
                'username' => $username,
                'password' => $password
            ];
            
            $success = 'Conexão com o banco de dados bem-sucedida!';
            $step = 2;
        } catch (PDOException $e) {
            $error = 'Erro na conexão com o banco de dados: ' . $e->getMessage();
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 2) {
    // Step 2: Save configuration
    if (isset($_SESSION['db_credentials'])) {
        $creds = $_SESSION['db_credentials'];
        
        // Generate and save configuration.php
        $configContent = generateConfigFile(
            $creds['host'],
            $creds['db_name'],
            $creds['username'],
            $creds['password']
        );
        
        // Generate and save database.php
        $databaseContent = generateDatabaseFile(
            $creds['host'],
            $creds['db_name'],
            $creds['username'],
            $creds['password']
        );
        
        // Attempt to write files
        $configWritten = file_put_contents('configuration.php', $configContent);
        $databaseWritten = file_put_contents('database.php', $databaseContent);
        
        if ($configWritten !== false && $databaseWritten !== false) {
            // Try to create tables and update schema
            try {
                $dsn = "pgsql:host={$creds['host']};dbname={$creds['db_name']}";
                $pdo = new PDO($dsn, $creds['username'], $creds['password']);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                $sql = "CREATE TABLE IF NOT EXISTS agendamentos (
                    id SERIAL PRIMARY KEY,
                    nome_paciente VARCHAR(255) NOT NULL,
                    ano_nascimento INTEGER NOT NULL,
                    tipo_eeg VARCHAR(255) NOT NULL,
                    data_agendamento VARCHAR(10) NOT NULL,
                    horario VARCHAR(5) NOT NULL,
                    dia_semana VARCHAR(20) NOT NULL,
                    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT unique_data_horario UNIQUE (data_agendamento, horario)
                )";
                
                $pdo->exec($sql);
                
                // Check and add dia_semana column if missing
                $checkColumn = $pdo->query("SELECT column_name FROM information_schema.columns WHERE table_name = 'agendamentos' AND column_name = 'dia_semana'");
                if ($checkColumn->rowCount() == 0) {
                    $alterSql = "ALTER TABLE agendamentos ADD COLUMN dia_semana VARCHAR(20) NOT NULL";
                    $pdo->exec($alterSql);
                    
                    // Update existing records with dia_semana
                    $updateSql = "UPDATE agendamentos SET dia_semana = CASE 
                        WHEN data_agendamento ~ '^[0-3][0-9]/[0-1][0-9]/[0-9]{4}$' THEN 
                            to_char(to_date(data_agendamento, 'DD/MM/YYYY'), 'Day')
                        ELSE 'Unknown'
                    END";
                    $pdo->exec($updateSql);
                }
                
                $success = 'Instalação concluída com sucesso! Arquivos de configuração salvos e tabelas atualizadas.';
                $step = 3;
                
                // Clear session data
                unset($_SESSION['db_credentials']);
            } catch (PDOException $e) {
                $error = 'Erro ao criar ou atualizar tabelas: ' . $e->getMessage();
            }
        } else {
            $error = 'Erro ao salvar arquivos de configuração. Verifique as permissões de escrita no diretório.';
        }
    } else {
        $error = 'Dados de conexão não encontrados. Por favor, comece novamente.';
        $step = 1;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação - Sistema de Agendamento EEG</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
        .error {
            color: #d32f2f;
            padding: 10px;
            background-color: #ffebee;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .success {
            color: #2e7d32;
            padding: 10px;
            background-color: #e8f5e9;
            border-radius: 4px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Instalação - Sistema de Agendamento EEG</h1>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if ($step === 1): ?>
            <form method="post">
                <input type="hidden" name="step" value="1">
                <div class="form-group">
                    <label for="host">Host do Banco de Dados:</label>
                    <input type="text" id="host" name="host" value="pgsql.examesneurologicos.com.br" required>
                </div>
                <div class="form-group">
                    <label for="db_name">Nome do Banco de Dados:</label>
                    <input type="text" id="db_name" name="db_name" value="examesneurologicos" required>
                </div>
                <div class="form-group">
                    <label for="username">Usuário do Banco de Dados:</label>
                    <input type="text" id="username" name="username" value="examesneurologicos" required>
                </div>
                <div class="form-group">
                    <label for="password">Senha do Banco de Dados:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit">Testar Conexão</button>
            </form>
        <?php elseif ($step === 2): ?>
            <form method="post">
                <input type="hidden" name="step" value="2">
                <p>Conexão testada com sucesso! Clique abaixo para salvar a configuração e criar/atualizar as tabelas necessárias.</p>
                <button type="submit">Salvar Configuração e Concluir</button>
            </form>
        <?php elseif ($step === 3): ?>
            <p>A instalação foi concluída com sucesso! Você pode agora:</p>
            <ul>
                <li><a href="index.html">Acessar a página de agendamento</a></li>
                <li><a href="admin.html">Acessar a página de administração</a></li>
            </ul>
        <?php endif; ?>
    </div>
</body>
</html>