<?php
require_once 'database.php';

// Script para migrar dados do arquivo horarios.txt para o banco de dados MySQL
$db = new Database();

// Ler dados do arquivo original
$horariosFile = '../upload/horarios.txt';
if (!file_exists($horariosFile)) {
    echo "Arquivo horarios.txt não encontrado.\n";
    exit;
}

$lines = file($horariosFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$migrated = 0;
$errors = 0;

echo "Iniciando migração de dados para MySQL...\n";

foreach ($lines as $line) {
    $line = trim($line);
    if (empty($line)) continue;
    
    // Formato esperado: "DD/MM/YYYY HH:MM"
    $parts = explode(' ', $line);
    if (count($parts) != 2) {
        echo "Formato inválido: $line\n";
        $errors++;
        continue;
    }
    
    $dataAgendamento = $parts[0];
    $horario = $parts[1];
    
    // Como não temos os dados completos do paciente no arquivo original,
    // vamos criar registros com dados genéricos para manter os horários ocupados
    $result = $db->agendarHorario(
        'Paciente Migrado', 
        2000, 
        'EEG Migrado', 
        $dataAgendamento, 
        $horario
    );
    
    if ($result['success']) {
        $migrated++;
        echo "Migrado: $line\n";
    } else {
        echo "Erro ao migrar $line: " . $result['message'] . "\n";
        $errors++;
    }
}

echo "\nMigração concluída!\n";
echo "Registros migrados: $migrated\n";
echo "Erros: $errors\n";
?>

