<?php
class Database {
    private $pdo;
    private $host = 'pgsql.examesneurologicos.com.br';
    private $db_name = 'examesneurologicos';
    private $username = 'examesneurologicos';
    private $password = 'FRED4321';

    public function __construct() {
        $dsn = "pgsql:host={$this->host};dbname={$this->db_name}";
        try {
            $this->pdo = new PDO($dsn, $this->username, $this->password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->createTables();
        } catch (PDOException $e) {
            die('Erro na conexão com o banco de dados: ' . $e->getMessage());
        }
    }
    
    private function createTables() {
        $sql = "CREATE TABLE IF NOT EXISTS agendamentos (
            id SERIAL PRIMARY KEY,
            nome_paciente VARCHAR(255) NOT NULL,
            ano_nascimento INTEGER NOT NULL,
            tipo_eeg VARCHAR(255) NOT NULL,
            data_agendamento VARCHAR(10) NOT NULL,
            horario VARCHAR(5) NOT NULL,
            dia_semana VARCHAR(20) NOT NULL,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT unique_data_horario UNIQUE (data_agendamento, horario)
        )";
        
        $this->pdo->exec($sql);
        
        // Check and add dia_semana column if missing
        $checkColumn = $this->pdo->query("SELECT column_name FROM information_schema.columns WHERE table_name = 'agendamentos' AND column_name = 'dia_semana'");
        if ($checkColumn->rowCount() == 0) {
            $alterSql = "ALTER TABLE agendamentos ADD COLUMN dia_semana VARCHAR(20) NOT NULL";
            $this->pdo->exec($alterSql);
            
            // Update existing records with dia_semana
            $updateSql = "UPDATE agendamentos SET dia_semana = CASE 
                WHEN data_agendamento ~ '^[0-3][0-9]/[0-1][0-9]/[0-9]{4}$' THEN 
                    to_char(to_date(data_agendamento, 'DD/MM/YYYY'), 'Day')
                ELSE 'Unknown'
            END";
            $this->pdo->exec($updateSql);
        }
    }
    
    public function getConnection() {
        return $this->pdo;
    }
    
    public function getHorariosOcupados() {
        $stmt = $this->pdo->prepare("SELECT data_agendamento, horario FROM agendamentos");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $horarios = [];
        foreach ($result as $row) {
            $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'];
        }
        
        return $horarios;
    }
    
    public function getHorariosOcupadosPorDia($dataAgendamento) {
        $stmt = $this->pdo->prepare("SELECT horario FROM agendamentos WHERE data_agendamento = ?");
        $stmt->execute([$dataAgendamento]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $horarios = [];
        foreach ($result as $row) {
            $horarios[] = $row['horario'];
        }
        
        return $horarios;
    }
    
    public function getHorariosDisponiveis($dataAgendamento, $diaSemana) {
        $horariosFixos = [
            'Monday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00'],
            'Tuesday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00'],
            'Wednesday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00'],
            'Thursday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00'],
            'Friday' => ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00']
        ];
        
        if (!isset($horariosFixos[$diaSemana])) {
            return [];
        }
        
        $horariosOcupados = $this->getHorariosOcupadosPorDia($dataAgendamento);
        $horariosDisponiveis = array_diff($horariosFixos[$diaSemana], $horariosOcupados);
        
        return array_values($horariosDisponiveis);
    }
    
    public function agendarHorario($nomePaciente, $anoNascimento, $tipoEeg, $dataAgendamento, $horario, $diaSemana = null) {
        try {
            if ($diaSemana === null) {
                $dateParts = explode('/', $dataAgendamento);
                if (count($dateParts) === 3) {
                    $dateObj = DateTime::createFromFormat('d/m/Y', $dataAgendamento);
                    if ($dateObj) {
                        $diaSemana = $dateObj->format('l');
                    }
                }
            }
            
            $stmt = $this->pdo->prepare("INSERT INTO agendamentos (nome_paciente, ano_nascimento, tipo_eeg, data_agendamento, horario, dia_semana) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$nomePaciente, $anoNascimento, $tipoEeg, $dataAgendamento, $horario, $diaSemana]);
            return ['success' => true, 'message' => 'Agendamento realizado com sucesso'];
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'unique_data_horario') !== false) {
                return ['success' => false, 'message' => 'Este horário já está ocupado'];
            }
            return ['success' => false, 'message' => 'Erro ao realizar agendamento: ' . $e->getMessage()];
        }
    }
    
    public function getAgendamentos() {
        $stmt = $this->pdo->prepare("SELECT * FROM agendamentos ORDER BY data_agendamento, horario");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function verificarDisponibilidade($dataAgendamento, $horario) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM agendamentos WHERE data_agendamento = ? AND horario = ?");
        $stmt->execute([$dataAgendamento, $horario]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['count'] == 0;
    }
}
?>