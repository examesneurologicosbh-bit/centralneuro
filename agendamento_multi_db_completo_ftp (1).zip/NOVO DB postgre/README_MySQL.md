# Sistema de Agendamento EEG - Versão MySQL

## Melhorias Implementadas

### 1. Banco de Dados MySQL
- Substituição do arquivo de texto por banco de dados MySQL remoto
- Estrutura robusta com tabela `agendamentos`
- Constraint UNIQUE para prevenir horários duplos
- Armazenamento completo dos dados do paciente

### 2. API REST
- Endpoint unificado (`api.php`) para todas as operações
- Suporte a CORS para integração frontend/backend
- Validação e sanitização completa dos dados
- Tratamento de erros robusto

### 3. Frontend Aprimorado
- Melhor tratamento de erros e feedback visual
- Estados de loading durante operações
- Mensagens de sucesso e erro
- Prevenção de duplo clique durante agendamento

### 4. Prevenção de Horários Duplos
- Verificação no banco de dados com constraint UNIQUE
- Tratamento de conflitos com mensagens específicas
- Atualização automática da lista de horários disponíveis

### 5. Página de Administração
- Visualização de todos os agendamentos
- Estatísticas em tempo real
- Interface responsiva para desktop e mobile

## Configuração do Banco de Dados

### Credenciais MySQL
- **Host:** mysql.mariadecorbh.com.br
- **Banco:** mariadecorbh
- **Usuário:** mariadecor_add1
- **Senha:** Fred5678

### Estrutura da Tabela

```sql
CREATE TABLE agendamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_paciente VARCHAR(255) NOT NULL,
    ano_nascimento INT NOT NULL,
    tipo_eeg VARCHAR(255) NOT NULL,
    data_agendamento VARCHAR(10) NOT NULL,
    horario VARCHAR(5) NOT NULL,
    data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(data_agendamento, horario)
);
```

## Estrutura de Arquivos

```
agendamento_melhorado/
├── index.html              # Frontend principal
├── api.php                # API REST
├── database.php           # Classe de banco de dados MySQL
├── admin.html             # Página de administração
├── migrate_data_mysql.php # Script de migração para MySQL
├── README_MySQL.md        # Esta documentação
└── agendamentos.db        # Banco SQLite (versão anterior)
```

## Instalação

1. Copie todos os arquivos para o servidor web
2. Certifique-se de que o PHP tem a extensão MySQL/MySQLi habilitada
3. Execute o script de migração (opcional):
   ```bash
   php migrate_data_mysql.php
   ```

## Uso

### Frontend Principal
- Acesse `index.html` para fazer agendamentos
- Todos os campos são obrigatórios
- Sistema previne horários duplos automaticamente

### Administração
- Acesse `admin.html` para visualizar agendamentos
- Estatísticas atualizadas em tempo real
- Lista completa de todos os agendamentos

## API Endpoints

### GET api.php?action=horarios-ocupados
Retorna lista de horários já agendados

### GET api.php?action=agendamentos
Retorna todos os agendamentos (para administração)

### POST api.php?action=agendar
Cria novo agendamento
```json
{
  "nomePaciente": "Nome do Paciente",
  "anoNascimento": 1990,
  "tipoEeg": "EEG Rotina - R$120,00",
  "dataAgendamento": "16/08/2025",
  "horario": "14:00"
}
```

## Banco de Dados MySQL

### Tabela: agendamentos
- `id` (INT AUTO_INCREMENT PRIMARY KEY)
- `nome_paciente` (VARCHAR(255) NOT NULL)
- `ano_nascimento` (INT NOT NULL)
- `tipo_eeg` (VARCHAR(255) NOT NULL)
- `data_agendamento` (VARCHAR(10) NOT NULL)
- `horario` (VARCHAR(5) NOT NULL)
- `data_criacao` (DATETIME DEFAULT CURRENT_TIMESTAMP)
- UNIQUE constraint em (`data_agendamento`, `horario`)

## Segurança

- Validação completa de todos os dados de entrada
- Sanitização de dados antes do armazenamento
- Prepared statements para prevenir SQL injection
- Headers CORS configurados adequadamente
- Conexão segura com banco MySQL remoto

## Compatibilidade

- PHP 7.0+ com extensão MySQL/MySQLi
- MySQL 5.7+ ou MariaDB 10.2+
- Navegadores modernos com suporte a ES6
- Responsivo para desktop e mobile

## Vantagens do MySQL vs SQLite

1. **Escalabilidade**: Suporta múltiplos usuários simultâneos
2. **Robustez**: Melhor para aplicações em produção
3. **Backup**: Facilita backup e recuperação de dados
4. **Administração**: Ferramentas avançadas de administração
5. **Performance**: Melhor performance para grandes volumes de dados

