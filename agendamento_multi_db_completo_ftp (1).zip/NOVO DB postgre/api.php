<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once 'database.php';

try {
    $db = new Database();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro de conexão com o banco de dados: ' . $e->getMessage()]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'GET':
        handleGetRequest($db, $action);
        break;
        
    case 'POST':
        handlePostRequest($db, $action);
        break;
        
    case 'PUT':
        handlePutRequest($db, $action);
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método não permitido']);
        break;
}

function handleGetRequest($db, $action) {
    switch ($action) {
        case 'horarios-ocupados':
            $horariosOcupados = $db->getHorariosOcupados();
            echo json_encode($horariosOcupados);
            break;
            
        case 'horarios-disponiveis':
            $dataAgendamento = $_GET['data'] ?? '';
            $diaSemana = $_GET['dia'] ?? '';
            
            if (empty($dataAgendamento) || empty($diaSemana)) {
                http_response_code(400);
                echo json_encode(['error' => 'Data e dia da semana são obrigatórios']);
                exit;
            }
            
            $horariosDisponiveis = $db->getHorariosDisponiveis($dataAgendamento, $diaSemana);
            echo json_encode($horariosDisponiveis);
            break;
            
        case 'verificar-disponibilidade':
            $dataAgendamento = $_GET['data'] ?? '';
            $horario = $_GET['horario'] ?? '';
            
            if (empty($dataAgendamento) || empty($horario)) {
                http_response_code(400);
                echo json_encode(['error' => 'Data e horário são obrigatórios']);
                exit;
            }
            
            $disponivel = $db->verificarDisponibilidade($dataAgendamento, $horario);
            echo json_encode(['disponivel' => $disponivel]);
            break;
            
        case 'agendamentos':
            $filtros = [
                'data' => $_GET['data'] ?? '',
                'tipo' => $_GET['tipo'] ?? '',
                'paciente' => $_GET['paciente'] ?? '',
                'status' => $_GET['status'] ?? ''
            ];
            
            $agendamentos = $db->getAgendamentos($filtros);
            echo json_encode($agendamentos);
            break;
            
        case 'estatisticas':
            $estatisticas = $db->getEstatisticas();
            echo json_encode($estatisticas);
            break;
            
        case 'proximos-horarios':
            $dias = (int)($_GET['dias'] ?? 5);
            $horarios = $db->getProximosHorariosDisponiveis($dias);
            echo json_encode($horarios);
            break;
            
        case 'texto-horarios-disponiveis':
            $dias = (int)($_GET['dias'] ?? 5);
            $texto = $db->gerarTextoHorariosDisponiveis($dias);
            echo json_encode(['texto' => $texto]);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Ação não especificada ou inválida']);
    }
}

function handlePostRequest($db, $action) {
    switch ($action) {
        case 'agendar':
            $input = json_decode(file_get_contents('php://input'), true);
            
            // Validação dos dados
            if (empty($input['nomePaciente']) || empty($input['anoNascimento']) || 
                empty($input['tipoEeg']) || empty($input['dataAgendamento']) || 
                empty($input['horario'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Todos os campos são obrigatórios']);
                exit;
            }
            
            // Sanitização dos dados
            $nomePaciente = trim($input['nomePaciente']);
            $anoNascimento = (int)$input['anoNascimento'];
            $tipoEeg = trim($input['tipoEeg']);
            $dataAgendamento = trim($input['dataAgendamento']);
            $horario = trim($input['horario']);
            $diaSemana = trim($input['diaSemana'] ?? '');
            
            // Validações adicionais
            if ($anoNascimento < 1900 || $anoNascimento > date('Y')) {
                http_response_code(400);
                echo json_encode(['error' => 'Ano de nascimento inválido']);
                exit;
            }
            
            if (!preg_match('/^\d{2}\/\d{2}\/\d{4}$/', $dataAgendamento)) {
                http_response_code(400);
                echo json_encode(['error' => 'Formato de data inválido (use dd/mm/aaaa)']);
                exit;
            }
            
            if (!preg_match('/^\d{2}:\d{2}$/', $horario)) {
                http_response_code(400);
                echo json_encode(['error' => 'Formato de horário inválido (use hh:mm)']);
                exit;
            }
            
            // Verificar disponibilidade antes de agendar
            if (!$db->verificarDisponibilidade($dataAgendamento, $horario)) {
                http_response_code(409);
                echo json_encode(['error' => 'Este horário já está ocupado']);
                exit;
            }
            
            $result = $db->agendarHorario($nomePaciente, $anoNascimento, $tipoEeg, $dataAgendamento, $horario, $diaSemana);
            
            if ($result['success']) {
                echo json_encode(['success' => true, 'message' => $result['message']]);
            } else {
                http_response_code(409); // Conflict
                echo json_encode(['error' => $result['message']]);
            }
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Ação não especificada ou inválida']);
    }
}

function handlePutRequest($db, $action) {
    switch ($action) {
        case 'atualizar-status':
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (empty($input['id']) || empty($input['status'])) {
                http_response_code(400);
                echo json_encode(['error' => 'ID e status são obrigatórios']);
                exit;
            }
            
            $id = (int)$input['id'];
            $status = trim($input['status']);
            
            if (!in_array($status, ['agendado', 'realizado', 'cancelado'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Status inválido']);
                exit;
            }
            
            $result = $db->atualizarStatusAgendamento($id, $status);
            
            if ($result['success']) {
                echo json_encode(['success' => true, 'message' => $result['message']]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => $result['message']]);
            }
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Ação não especificada ou inválida']);
    }
}
?>

