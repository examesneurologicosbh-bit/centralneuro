<?php
if (isset($_POST['slot'])) {
    $slot = $_POST['slot'];
    $slot = preg_replace('/[^0-9\/ :]/', '', $slot); // Sanitize input
    $file = "horarios.txt";
    
    if (!empty($slot)) {
        $result = file_put_contents($file, $slot . PHP_EOL, FILE_APPEND | LOCK_EX);
        if ($result !== false) {
            echo 'Success';
        } else {
            echo 'Error';
        }
    } else {
        echo 'Error';
    }
} else {
    echo 'Error';
}
?>