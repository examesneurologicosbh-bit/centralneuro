<?php
$file = "horarios.txt";
$bookedSlots = [];

if (file_exists($file)) {
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $bookedSlots[] = trim($line);
    }
}

header('Content-Type: application/json');
echo json_encode($bookedSlots);
?>