<?php
// Configurações do Banco de Dados
// Estas configurações serão preenchidas automaticamente pelo install.php

define("DB_TYPE", ""); // mysql, sqlite, pgsql, firebird
define("DB_HOST", "");
define("DB_PORT", ""); // Opcional, padrão para cada tipo de DB
define("DB_NAME", "");
define("DB_USER", "");
define("DB_PASS", "");
define("DB_CHARSET", "utf8mb4");

// Configurações de Exames e Horários (Exemplo)
// Estas configurações devem ser gerenciadas via interface administrativa ou diretamente no banco de dados
// A estrutura abaixo é apenas um exemplo de como os dados podem ser representados

$GLOBALS["EXAMS_CONFIG"] = [
    "EEG" => [
        "tipos" => [
            ["id" => 1, "nome" => "EEG de Rotina", "valor" => 250.00],
            ["id" => 2, "nome" => "EEG com Mapeamento", "valor" => 350.00]
        ],
        "horarios" => [
            "Monday" => ["08:00", "09:00", "10:00", "13:00", "14:00", "15:00"],
            "Tuesday" => ["08:00", "09:00", "10:00", "13:00", "14:00", "15:00"],
            "Wednesday" => ["08:00", "09:00", "10:00", "13:00", "14:00", "15:00"],
            "Thursday" => ["08:00", "09:00", "10:00", "13:00", "14:00", "15:00"],
            "Friday" => ["08:00", "09:00", "10:00", "13:00", "14:00", "15:00"]
        ]
    ],
    "ENMG" => [
        "tipos" => [
            ["id" => 3, "nome" => "Eletroneuromiografia de Membros Superiores", "valor" => 400.00],
            ["id" => 4, "nome" => "Eletroneuromiografia de Membros Inferiores", "valor" => 400.00]
        ],
        "horarios" => [
            "Monday" => ["16:00", "17:00"],
            "Wednesday" => ["16:00", "17:00"]
        ]
    ],
    "POLI" => [
        "tipos" => [
            ["id" => 5, "nome" => "Polissonografia Domiciliar", "valor" => 800.00]
        ],
        "horarios" => [
            "Tuesday" => ["18:00", "19:00"],
            "Thursday" => ["18:00", "19:00"]
        ]
    ]
];

// Número de WhatsApp para contato (exemplo)
define("WHATSAPP_NUMBER", "553130581685");

// Status de agendamento
define("STATUS_AGENDADO", "agendado");
define("STATUS_REALIZADO", "realizado");
define("STATUS_CANCELADO", "cancelado");

// Dias da semana em português para exibição
$GLOBALS["DAY_NAMES_PT"] = [
    "Sunday" => "Domingo",
    "Monday" => "Segunda-feira",
    "Tuesday" => "Terça-feira",
    "Wednesday" => "Quarta-feira",
    "Thursday" => "Quinta-feira",
    "Friday" => "Sexta-feira",
    "Saturday" => "Sábado"
];

?>

