<?php
class Database {
    private $pdo;
    
    public function __construct() {
        try {
            $this->pdo = new PDO('sqlite:agendamentos.db');
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->createTables();
        } catch (PDOException $e) {
            die('Erro na conexão com o banco de dados: ' . $e->getMessage());
        }
    }
    
    private function createTables() {
        $sql = "CREATE TABLE IF NOT EXISTS agendamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome_paciente TEXT NOT NULL,
            ano_nascimento INTEGER NOT NULL,
            tipo_eeg TEXT NOT NULL,
            data_agendamento TEXT NOT NULL,
            horario TEXT NOT NULL,
            data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(data_agendamento, horario)
        )";
        
        $this->pdo->exec($sql);
    }
    
    public function getConnection() {
        return $this->pdo;
    }
    
    public function getHorariosOcupados() {
        $stmt = $this->pdo->prepare("SELECT data_agendamento, horario FROM agendamentos");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $horarios = [];
        foreach ($result as $row) {
            $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'];
        }
        
        return $horarios;
    }
    
    public function agendarHorario($nomePaciente, $anoNascimento, $tipoEeg, $dataAgendamento, $horario) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO agendamentos (nome_paciente, ano_nascimento, tipo_eeg, data_agendamento, horario) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$nomePaciente, $anoNascimento, $tipoEeg, $dataAgendamento, $horario]);
            return ['success' => true, 'message' => 'Agendamento realizado com sucesso'];
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // UNIQUE constraint failed
                return ['success' => false, 'message' => 'Este horário já está ocupado'];
            }
            return ['success' => false, 'message' => 'Erro ao realizar agendamento: ' . $e->getMessage()];
        }
    }
    
    public function getAgendamentos() {
        $stmt = $this->pdo->prepare("SELECT * FROM agendamentos ORDER BY data_agendamento, horario");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

