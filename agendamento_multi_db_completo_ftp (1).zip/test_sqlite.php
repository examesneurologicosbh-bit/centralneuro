<?php

// Simula a configuração para SQLite
define("DB_TYPE", "sqlite");
define("DB_HOST", ""); // Não aplicável para SQLite
define("DB_PORT", ""); // Não aplicável para SQLite
define("DB_NAME", "agendamentos.db"); // Nome do arquivo do banco de dados SQLite
define("DB_USER", ""); // Não aplicável para SQLite
define("DB_PASS", ""); // Não aplicável para SQLite
define("DB_CHARSET", "utf8mb4");

require_once 'DatabaseManager.php';

try {
    $dbManager = new DatabaseManager();
    if ($dbManager->testConnection()) {
        echo "Conexão SQLite bem-sucedida.\n";
        $dbManager->createTables();
        echo "Tabelas SQLite criadas/verificadas.\n";
        $dbManager->insertInitialData();
        echo "Dados iniciais SQLite inseridos/verificados.\n";
    } else {
        echo "Falha na conexão SQLite.\n";
    }
} catch (Exception $e) {
    echo "Erro no teste SQLite: " . $e->getMessage() . "\n";
}

?>

