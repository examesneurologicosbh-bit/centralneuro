<?php

// Simula a configuração para MySQL
define("DB_TYPE", "mysql");
define("DB_HOST", "localhost");
define("DB_PORT", "3306");
define("DB_NAME", "test_db_mysql");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_CHARSET", "utf8mb4");

require_once 'DatabaseManager.php';

try {
    $dbManager = new DatabaseManager();
    if ($dbManager->testConnection()) {
        echo "Conexão MySQL bem-sucedida.\n";
        $dbManager->createTables();
        echo "Tabelas MySQL criadas/verificadas.\n";
        $dbManager->insertInitialData();
        echo "Dados iniciais MySQL inseridos/verificados.\n";
    } else {
        echo "Falha na conexão MySQL.\n";
    }
} catch (Exception $e) {
    echo "Erro no teste MySQL: " . $e->getMessage() . "\n";
}

?>

