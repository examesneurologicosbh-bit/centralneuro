<?php

// Simula a configuração para PostgreSQL
define("DB_TYPE", "pgsql");
define("DB_HOST", "localhost");
define("DB_PORT", "5432");
define("DB_NAME", "test_db_pgsql");
define("DB_USER", "postgres");
define("DB_PASS", "password");
define("DB_CHARSET", "utf8");

require_once 'DatabaseManager.php';

try {
    $dbManager = new DatabaseManager();
    if ($dbManager->testConnection()) {
        echo "Conexão PostgreSQL bem-sucedida.\n";
        $dbManager->createTables();
        echo "Tabelas PostgreSQL criadas/verificadas.\n";
        $dbManager->insertInitialData();
        echo "Dados iniciais PostgreSQL inseridos/verificados.\n";
    } else {
        echo "Falha na conexão PostgreSQL.\n";
    }
} catch (Exception $e) {
    echo "Erro no teste PostgreSQL: " . $e->getMessage() . "\n";
}

?>

