<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once 'database_new.php';

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'GET':
        if ($action === 'categorias') {
            $categorias = $db->getCategorias();
            echo json_encode($categorias);
            
        } elseif ($action === 'tipos-exames') {
            $categoria = $_GET['categoria'] ?? '';
            if (empty($categoria)) {
                http_response_code(400);
                echo json_encode(['error' => 'Categoria não especificada']);
                exit;
            }
            
            $tipos = $db->getTiposPorCategoria($categoria);
            echo json_encode($tipos);
            
        } elseif ($action === 'horarios-categoria') {
            $categoria = $_GET['categoria'] ?? '';
            if (empty($categoria)) {
                http_response_code(400);
                echo json_encode(['error' => 'Categoria não especificada']);
                exit;
            }
            
            $horarios = $db->getHorariosPorCategoria($categoria);
            echo json_encode($horarios);
            
        } elseif ($action === 'horarios-ocupados') {
            $categoria = $_GET['categoria'] ?? null;
            $horariosOcupados = $db->getHorariosOcupados($categoria);
            echo json_encode($horariosOcupados);
            
        } elseif ($action === 'agendamentos') {
            $categoria = $_GET['categoria'] ?? null;
            $agendamentos = $db->getAgendamentos($categoria);
            echo json_encode($agendamentos);
            
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Ação não especificada']);
        }
        break;
        
    case 'POST':
        if ($action === 'agendar') {
            $input = json_decode(file_get_contents('php://input'), true);
            
            // Validação dos dados
            if (empty($input['nomePaciente']) || empty($input['anoNascimento']) || 
                empty($input['categoriaExame']) || empty($input['tipoExameId']) || 
                empty($input['dataAgendamento']) || empty($input['horario'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Todos os campos são obrigatórios']);
                exit;
            }
            
            // Sanitização dos dados
            $nomePaciente = trim($input['nomePaciente']);
            $anoNascimento = (int)$input['anoNascimento'];
            $categoriaExame = trim($input['categoriaExame']);
            $tipoExameId = (int)$input['tipoExameId'];
            $dataAgendamento = trim($input['dataAgendamento']);
            $horario = trim($input['horario']);
            
            // Validações adicionais
            if ($anoNascimento < 1900 || $anoNascimento > date('Y')) {
                http_response_code(400);
                echo json_encode(['error' => 'Ano de nascimento inválido']);
                exit;
            }
            
            if (!preg_match('/^\d{2}\/\d{2}\/\d{4}$/', $dataAgendamento)) {
                http_response_code(400);
                echo json_encode(['error' => 'Formato de data inválido']);
                exit;
            }
            
            if (!preg_match('/^\d{2}:\d{2}$/', $horario)) {
                http_response_code(400);
                echo json_encode(['error' => 'Formato de horário inválido']);
                exit;
            }
            
            // Validar se a categoria é válida
            $categorias = $db->getCategorias();
            if (!in_array($categoriaExame, $categorias)) {
                http_response_code(400);
                echo json_encode(['error' => 'Categoria de exame inválida']);
                exit;
            }
            
            // Validar se o tipo de exame pertence à categoria
            $tipos = $db->getTiposPorCategoria($categoriaExame);
            $tipoValido = false;
            foreach ($tipos as $tipo) {
                if ($tipo['id'] == $tipoExameId) {
                    $tipoValido = true;
                    break;
                }
            }
            
            if (!$tipoValido) {
                http_response_code(400);
                echo json_encode(['error' => 'Tipo de exame não pertence à categoria selecionada']);
                exit;
            }
            
            // Validar se o horário é válido para a categoria
            $horariosCategoria = $db->getHorariosPorCategoria($categoriaExame);
            $horarioValido = false;
            
            // Converter data para dia da semana
            $dataObj = DateTime::createFromFormat('d/m/Y', $dataAgendamento);
            if (!$dataObj) {
                http_response_code(400);
                echo json_encode(['error' => 'Data inválida']);
                exit;
            }
            
            $diaSemana = $dataObj->format('l'); // Monday, Tuesday, etc.
            
            if (isset($horariosCategoria[$diaSemana]) && in_array($horario, $horariosCategoria[$diaSemana])) {
                $horarioValido = true;
            }
            
            if (!$horarioValido) {
                http_response_code(400);
                echo json_encode(['error' => 'Horário não disponível para esta categoria neste dia']);
                exit;
            }
            
            $result = $db->agendarHorario($nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario);
            
            if ($result['success']) {
                echo json_encode([
                    'success' => true, 
                    'message' => $result['message'],
                    'tipo_exame' => $result['tipo_exame'],
                    'valor' => $result['valor']
                ]);
            } else {
                http_response_code(409); // Conflict
                echo json_encode(['error' => $result['message']]);
            }
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Ação não especificada']);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método não permitido']);
        break;
}
?>

