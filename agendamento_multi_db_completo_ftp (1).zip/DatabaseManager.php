<?php

interface IDatabaseAdapter {
    public function connect($config);
    public function createTables();
    public function getHorariosOcupados($categoria = null);
    public function agendarHorario($nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario);
    public function getAgendamentos($filtros = []);
    public function getCategorias();
    public function getTiposPorCategoria($categoria);
    public function getHorariosPorCategoria($categoria);
    public function verificarDisponibilidade($categoriaExame, $dataAgendamento, $horario);
    public function getEstatisticas();
    public function getProximosHorariosDisponiveis($dias = 5);
    public function gerarTextoHorariosDisponiveis($dias = 5);
    public function atualizarStatusAgendamento($id, $status);
}

class MySQLAdapter implements IDatabaseAdapter {
    private $pdo;
    private $config;

    public function connect($config) {
        $this->config = $config;
        $dsn = "mysql:host={$config["host"]};port={$config["port"]};dbname={$config["dbname"]};charset={$config["charset"]}";
        $this->pdo = new PDO($dsn, $config["username"], $config["password"]);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    public function createTables() {
        $sql = "CREATE TABLE IF NOT EXISTS agendamentos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome_paciente VARCHAR(255) NOT NULL,
            ano_nascimento INT NOT NULL,
            tipo_eeg VARCHAR(255),
            categoria_exame VARCHAR(50) NOT NULL,
            tipo_exame_id INT NOT NULL,
            data_agendamento VARCHAR(10) NOT NULL,
            horario VARCHAR(5) NOT NULL,
            data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
            status ENUM(\'agendado\',\'realizado\',\'cancelado\') DEFAULT \'agendado\',
            UNIQUE(categoria_exame, data_agendamento, horario)
        )";
        $this->pdo->exec($sql);

        $sql = "CREATE TABLE IF NOT EXISTS tipos_exames (
            id INT AUTO_INCREMENT PRIMARY KEY,
            categoria VARCHAR(50) NOT NULL,
            nome VARCHAR(255) NOT NULL,
            valor DECIMAL(10,2) NOT NULL,
            ativo BOOLEAN DEFAULT TRUE
        )";
        $this->pdo->exec($sql);

        $sql = "CREATE TABLE IF NOT EXISTS horarios_tipos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            categoria VARCHAR(50) NOT NULL,
            dia_semana VARCHAR(20) NOT NULL,
            horario VARCHAR(5) NOT NULL,
            ativo BOOLEAN DEFAULT TRUE
        )";
        $this->pdo->exec($sql);

        $this->populateInitialData();
    }

    private function populateInitialData() {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM tipos_exames");
        $stmt->execute();
        if ($stmt->fetchColumn() > 0) {
            return;
        }

        $tiposExames = [
            ["EEG", "EEG Mapeamento", 240.00],
            ["EEG", "EEG Rotina", 120.00],
            ["EEG", "EEG Sono Vigília", 220.00],
            ["EEG", "EEG Concurso", 200.00],
            ["EEG", "EEG Infantil", 250.00],
            ["ENMG", "ENMG Membros Superiores", 180.00],
            ["ENMG", "ENMG Membros Inferiores", 180.00],
            ["ENMG", "ENMG Completo", 320.00],
            ["ENMG", "ENMG Face", 150.00],
            ["TC", "TC Crânio", 280.00],
            ["TC", "TC Tórax", 300.00],
            ["TC", "TC Abdome", 320.00],
            ["TC", "TC Coluna", 290.00],
            ["RM", "RM Crânio", 450.00],
            ["RM", "RM Coluna", 480.00],
            ["RM", "RM Joelho", 420.00],
            ["RM", "RM Abdome", 500.00],
            ["POLI", "Polissonografia Completa", 380.00],
            ["POLI", "Polissonografia Reduzida", 280.00]
        ];

        $stmt = $this->pdo->prepare("INSERT INTO tipos_exames (categoria, nome, valor) VALUES (?, ?, ?)");
        foreach ($tiposExames as $tipo) {
            $stmt->execute($tipo);
        }

        $horariosCategoria = [
            ["EEG", "Monday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Tuesday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Wednesday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Thursday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Friday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00"]],
            ["ENMG", "Monday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["ENMG", "Wednesday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["ENMG", "Friday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["TC", "Monday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Tuesday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Wednesday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Thursday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["RM", "Tuesday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["RM", "Thursday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["RM", "Saturday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["POLI", "Monday", ["20:00", "21:00"]],
            ["POLI", "Wednesday", ["20:00", "21:00"]]
        ];

        $stmt = $this->pdo->prepare("INSERT INTO horarios_tipos (categoria, dia_semana, horario) VALUES (?, ?, ?)");
        foreach ($horariosCategoria as $categoria) {
            $cat = $categoria[0];
            $dia = $categoria[1];
            $horarios = $categoria[2];

            foreach ($horarios as $horario) {
                $stmt->execute([$cat, $dia, $horario]);
            }
        }
    }

    public function getHorariosOcupados($categoria = null) {
        if ($categoria) {
            $stmt = $this->pdo->prepare("SELECT data_agendamento, horario FROM agendamentos WHERE categoria_exame = ? AND status = 'agendado'");
            $stmt->execute([$categoria]);
        } else {
            $stmt = $this->pdo->prepare("SELECT data_agendamento, horario, categoria_exame FROM agendamentos WHERE status = 'agendado'");
            $stmt->execute();
        }

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $horarios = [];
        foreach ($result as $row) {
            if ($categoria) {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'];
            } else {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'] . ' ' . $row['categoria_exame'];
            }
        }

        return $horarios;
    }

    public function agendarHorario($nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO agendamentos (nome_paciente, ano_nascimento, categoria_exame, tipo_exame_id, data_agendamento, horario, status) VALUES (?, ?, ?, ?, ?, ?, 'agendado')");
            $stmt->execute([$nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario]);

            $stmt = $this->pdo->prepare("SELECT nome, valor FROM tipos_exames WHERE id = ?");
            $stmt->execute([$tipoExameId]);
            $tipoExame = $stmt->fetch(PDO::FETCH_ASSOC);

            return [
                'success' => true,
                'message' => 'Agendamento realizado com sucesso',
                'tipo_exame_nome' => $tipoExame['nome'],
                'tipo_exame_valor' => $tipoExame['valor']
            ];
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                return ['success' => false, 'message' => 'Este horário já está ocupado para esta categoria'];
            }
            return ['success' => false, 'message' => 'Erro ao realizar agendamento: ' . $e->getMessage()];
        }
    }

    public function getAgendamentos($filtros = []) {
        $sql = "SELECT a.*, te.nome as tipo_exame_nome, te.valor FROM agendamentos a JOIN tipos_exames te ON a.tipo_exame_id = te.id WHERE 1=1";
        $params = [];

        if (!empty($filtros['data'])) {
            $sql .= " AND a.data_agendamento = ?";
            $params[] = $filtros['data'];
        }

        if (!empty($filtros['tipo_exame_id'])) {
            $sql .= " AND a.tipo_exame_id = ?";
            $params[] = $filtros['tipo_exame_id'];
        }

        if (!empty($filtros['categoria'])) {
            $sql .= " AND a.categoria_exame = ?";
            $params[] = $filtros['categoria'];
        }

        if (!empty($filtros['paciente'])) {
            $sql .= " AND a.nome_paciente LIKE ?";
            $params[] = '%' . $filtros['paciente'] . '%';
        }

        if (!empty($filtros['status'])) {
            $sql .= " AND a.status = ?";
            $params[] = $filtros['status'];
        }

        $sql .= " ORDER BY a.data_agendamento, a.horario";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getCategorias() {
        $stmt = $this->pdo->prepare("SELECT DISTINCT categoria FROM tipos_exames WHERE ativo = 1 ORDER BY categoria");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public function getTiposPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT id, nome, valor FROM tipos_exames WHERE categoria = ? AND ativo = 1 ORDER BY nome");
        $stmt->execute([$categoria]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getHorariosPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT dia_semana, horario FROM horarios_tipos WHERE categoria = ? AND ativo = 1 ORDER BY dia_semana, horario");
        $stmt->execute([$categoria]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $horarios = [];
        foreach ($result as $row) {
            if (!isset($horarios[$row['dia_semana']])) {
                $horarios[$row['dia_semana']] = [];
            }
            $horarios[$row['dia_semana']][] = $row['horario'];
        }

        return $horarios;
    }

    public function verificarDisponibilidade($categoriaExame, $dataAgendamento, $horario) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM agendamentos WHERE categoria_exame = ? AND data_agendamento = ? AND horario = ? AND status = 'agendado'");
        $stmt->execute([$categoriaExame, $dataAgendamento, $horario]);
        $result = $stmt->fetch();

        return $result['count'] == 0;
    }

    public function getEstatisticas() {
        $hoje = date('d/m/Y');
        $inicioSemana = date('d/m/Y', strtotime('monday this week'));
        $fimSemana = date('d/m/Y', strtotime('sunday this week'));

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total FROM agendamentos");
        $stmt->execute();
        $total = $stmt->fetch()['total'];

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as hoje FROM agendamentos WHERE data_agendamento = ? AND status = 'agendado'");
        $stmt->execute([$hoje]);
        $hoje_count = $stmt->fetch()['hoje'];

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as semana FROM agendamentos WHERE STRFTIME('%J', SUBSTR(data_agendamento, 7, 4) || '-' || SUBSTR(data_agendamento, 4, 2) || '-' || SUBSTR(data_agendamento, 1, 2)) BETWEEN STRFTIME('%J', SUBSTR(?, 7, 4) || '-' || SUBSTR(?, 4, 2) || '-' || SUBSTR(?, 1, 2)) AND STRFTIME('%J', SUBSTR(?, 7, 4) || '-' || SUBSTR(?, 4, 2) || '-' || SUBSTR(?, 1, 2)) AND status = 'agendado'");
        $stmt->execute([$inicioSemana, $inicioSemana, $inicioSemana, $fimSemana, $fimSemana, $fimSemana]);
        $semana_count = $stmt->fetch()['semana'];

        return [
            'total' => $total,
            'hoje' => $hoje_count,
            'semana' => $semana_count
        ];
    }

    public function getProximosHorariosDisponiveis($dias = 5) {
        $horariosFixos = $this->getHorariosPorCategoria('EEG'); // Default to EEG for now

        $dayNamesPT = [
            'Monday' => 'Segunda-feira',
            'Tuesday' => 'Terça-feira',
            'Wednesday' => 'Quarta-feira',
            'Thursday' => 'Quinta-feira',
            'Friday' => 'Sexta-feira',
            'Saturday' => 'Sábado',
            'Sunday' => 'Domingo'
        ];

        $resultado = [];
        $dataAtual = new DateTime();
        $diasProcessados = 0;

        while ($diasProcessados < $dias) {
            $diaSemanaEn = $dataAtual->format('l');
            $dataFormatada = $dataAtual->format('d/m');
            $dataCompleta = $dataAtual->format('d/m/Y');

            if (isset($horariosFixos[$diaSemanaEn])) {
                $horariosDisponiveis = array_diff(
                    $horariosFixos[$diaSemanaEn],
                    $this->getHorariosOcupadosPorDia('EEG', $dataCompleta)
                );

                if (!empty($horariosDisponiveis)) {
                    $resultado[] = [
                        'dia' => $dayNamesPT[$diaSemanaEn],
                        'data' => $dataFormatada,
                        'horarios' => array_values($horariosDisponiveis)
                    ];
                }
                $diasProcessados++;
            }

            $dataAtual->add(new DateInterval('P1D'));
        }

        return $resultado;
    }

    private function getHorariosOcupadosPorDia($categoria, $dataAgendamento) {
        $stmt = $this->pdo->prepare("SELECT horario FROM agendamentos WHERE categoria_exame = ? AND data_agendamento = ? AND status = 'agendado'");
        $stmt->execute([$categoria, $dataAgendamento]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public function gerarTextoHorariosDisponiveis($dias = 5) {
        $horarios = $this->getProximosHorariosDisponiveis($dias);
        $texto = "Segue horários disponíveis atualizados :\n\n";

        foreach ($horarios as $dia) {
            $texto .= $dia['dia'] . ' ' . $dia['data'] . ': ';

            $horariosFormatados = array_map(function($horario) {
                return str_replace(':00', 'hs', $horario);
            }, $dia['horarios']);

            $texto .= implode(' - ', $horariosFormatados) . "\n";
        }

        return $texto;
    }

    public function atualizarStatusAgendamento($id, $status) {
        try {
            $stmt = $this->pdo->prepare("UPDATE agendamentos SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
            return ['success' => true, 'message' => 'Status atualizado com sucesso'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'Erro ao atualizar status: ' . $e->getMessage()];
        }
    }
}

class PostgreSQLAdapter implements IDatabaseAdapter {
    private $pdo;
    private $config;

    public function connect($config) {
        $this->config = $config;
        $dsn = "pgsql:host={$config["host"]};port={$config["port"]};dbname={$config["dbname"]}";
        $this->pdo = new PDO($dsn, $config["username"], $config["password"]);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    public function createTables() {
        $sql = "CREATE TABLE IF NOT EXISTS agendamentos (
            id SERIAL PRIMARY KEY,
            nome_paciente VARCHAR(255) NOT NULL,
            ano_nascimento INTEGER NOT NULL,
            tipo_eeg VARCHAR(255),
            categoria_exame VARCHAR(50) NOT NULL,
            tipo_exame_id INTEGER NOT NULL,
            data_agendamento VARCHAR(10) NOT NULL,
            horario VARCHAR(5) NOT NULL,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status VARCHAR(20) DEFAULT 'agendado',
            UNIQUE(categoria_exame, data_agendamento, horario)
        )";
        $this->pdo->exec($sql);

        $sql = "CREATE TABLE IF NOT EXISTS tipos_exames (
            id SERIAL PRIMARY KEY,
            categoria VARCHAR(50) NOT NULL,
            nome VARCHAR(255) NOT NULL,
            valor DECIMAL(10,2) NOT NULL,
            ativo BOOLEAN DEFAULT TRUE
        )";
        $this->pdo->exec($sql);

        $sql = "CREATE TABLE IF NOT EXISTS horarios_tipos (
            id SERIAL PRIMARY KEY,
            categoria VARCHAR(50) NOT NULL,
            dia_semana VARCHAR(20) NOT NULL,
            horario VARCHAR(5) NOT NULL,
            ativo BOOLEAN DEFAULT TRUE
        )";
        $this->pdo->exec($sql);

        $this->populateInitialData();
    }

    private function populateInitialData() {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM tipos_exames");
        $stmt->execute();
        if ($stmt->fetchColumn() > 0) {
            return;
        }

        $tiposExames = [
            ["EEG", "EEG Mapeamento", 240.00],
            ["EEG", "EEG Rotina", 120.00],
            ["EEG", "EEG Sono Vigília", 220.00],
            ["EEG", "EEG Concurso", 200.00],
            ["EEG", "EEG Infantil", 250.00],
            ["ENMG", "ENMG Membros Superiores", 180.00],
            ["ENMG", "ENMG Membros Inferiores", 180.00],
            ["ENMG", "ENMG Completo", 320.00],
            ["ENMG", "ENMG Face", 150.00],
            ["TC", "TC Crânio", 280.00],
            ["TC", "TC Tórax", 300.00],
            ["TC", "TC Abdome", 320.00],
            ["TC", "TC Coluna", 290.00],
            ["RM", "RM Crânio", 450.00],
            ["RM", "RM Coluna", 480.00],
            ["RM", "RM Joelho", 420.00],
            ["RM", "RM Abdome", 500.00],
            ["POLI", "Polissonografia Completa", 380.00],
            ["POLI", "Polissonografia Reduzida", 280.00]
        ];

        $stmt = $this->pdo->prepare("INSERT INTO tipos_exames (categoria, nome, valor) VALUES (?, ?, ?)");
        foreach ($tiposExames as $tipo) {
            $stmt->execute($tipo);
        }

        $horariosCategoria = [
            ["EEG", "Monday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Tuesday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Wednesday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Thursday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Friday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00"]],
            ["ENMG", "Monday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["ENMG", "Wednesday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["ENMG", "Friday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["TC", "Monday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Tuesday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Wednesday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Thursday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["RM", "Tuesday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["RM", "Thursday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["RM", "Saturday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["POLI", "Monday", ["20:00", "21:00"]],
            ["POLI", "Wednesday", ["20:00", "21:00"]]
        ];

        $stmt = $this->pdo->prepare("INSERT INTO horarios_tipos (categoria, dia_semana, horario) VALUES (?, ?, ?)");
        foreach ($horariosCategoria as $categoria) {
            $cat = $categoria[0];
            $dia = $categoria[1];
            $horarios = $categoria[2];

            foreach ($horarios as $horario) {
                $stmt->execute([$cat, $dia, $horario]);
            }
        }
    }

    public function getHorariosOcupados($categoria = null) {
        if ($categoria) {
            $stmt = $this->pdo->prepare("SELECT TO_CHAR(data_agendamento, 'DD/MM/YYYY') as data_agendamento, horario FROM agendamentos WHERE categoria_exame = ? AND status = 'agendado'");
            $stmt->execute([$categoria]);
        } else {
            $stmt = $this->pdo->prepare("SELECT TO_CHAR(data_agendamento, 'DD/MM/YYYY') as data_agendamento, horario, categoria_exame FROM agendamentos WHERE status = 'agendado'");
            $stmt->execute();
        }

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $horarios = [];
        foreach ($result as $row) {
            if ($categoria) {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'];
            } else {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'] . ' ' . $row['categoria_exame'];
            }
        }

        return $horarios;
    }

    public function agendarHorario($nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO agendamentos (nome_paciente, ano_nascimento, categoria_exame, tipo_exame_id, data_agendamento, horario, status) VALUES (?, ?, ?, ?, TO_DATE(?, 'DD/MM/YYYY'), ?, 'agendado')");
            $stmt->execute([$nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario]);

            $stmt = $this->pdo->prepare("SELECT nome, valor FROM tipos_exames WHERE id = ?");
            $stmt->execute([$tipoExameId]);
            $tipoExame = $stmt->fetch(PDO::FETCH_ASSOC);

            return [
                'success' => true,
                'message' => 'Agendamento realizado com sucesso',
                'tipo_exame_nome' => $tipoExame['nome'],
                'tipo_exame_valor' => $tipoExame['valor']
            ];
        } catch (PDOException $e) {
            if ($e->getCode() == 23505) { // UNIQUE constraint failed for PostgreSQL
                return ['success' => false, 'message' => 'Este horário já está ocupado para esta categoria'];
            }
            return ['success' => false, 'message' => 'Erro ao realizar agendamento: ' . $e->getMessage()];
        }
    }

    public function getAgendamentos($filtros = []) {
        $sql = "SELECT a.*, te.nome as tipo_exame_nome, te.valor, TO_CHAR(a.data_agendamento, 'DD/MM/YYYY') as data_agendamento_formatada FROM agendamentos a JOIN tipos_exames te ON a.tipo_exame_id = te.id WHERE 1=1";
        $params = [];

        if (!empty($filtros['data'])) {
            $sql .= " AND TO_CHAR(a.data_agendamento, 'DD/MM/YYYY') = ?";
            $params[] = $filtros['data'];
        }

        if (!empty($filtros['tipo_exame_id'])) {
            $sql .= " AND a.tipo_exame_id = ?";
            $params[] = $filtros['tipo_exame_id'];
        }

        if (!empty($filtros['categoria'])) {
            $sql .= " AND a.categoria_exame = ?";
            $params[] = $filtros['categoria'];
        }

        if (!empty($filtros['paciente'])) {
            $sql .= " AND a.nome_paciente ILIKE ?"; // ILIKE for case-insensitive search in PostgreSQL
            $params[] = '%' . $filtros['paciente'] . '%';
        }

        if (!empty($filtros['status'])) {
            $sql .= " AND a.status = ?";
            $params[] = $filtros['status'];
        }

        $sql .= " ORDER BY a.data_agendamento, a.horario";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getCategorias() {
        $stmt = $this->pdo->prepare("SELECT DISTINCT categoria FROM tipos_exames WHERE ativo = TRUE ORDER BY categoria");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public function getTiposPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT id, nome, valor FROM tipos_exames WHERE categoria = ? AND ativo = TRUE ORDER BY nome");
        $stmt->execute([$categoria]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getHorariosPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT dia_semana, horario FROM horarios_tipos WHERE categoria = ? AND ativo = TRUE ORDER BY dia_semana, horario");
        $stmt->execute([$categoria]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $horarios = [];
        foreach ($result as $row) {
            if (!isset($horarios[$row['dia_semana']])) {
                $horarios[$row['dia_semana']] = [];
            }
            $horarios[$row['dia_semana']][] = $row['horario'];
        }

        return $horarios;
    }

    public function verificarDisponibilidade($categoriaExame, $dataAgendamento, $horario) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM agendamentos WHERE categoria_exame = ? AND TO_CHAR(data_agendamento, 'DD/MM/YYYY') = ? AND horario = ? AND status = 'agendado'");
        $stmt->execute([$categoriaExame, $dataAgendamento, $horario]);
        $result = $stmt->fetch();

        return $result['count'] == 0;
    }

    public function getEstatisticas() {
        $hoje = date('d/m/Y');
        $inicioSemana = date('d/m/Y', strtotime('monday this week'));
        $fimSemana = date('d/m/Y', strtotime('sunday this week'));

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total FROM agendamentos");
        $stmt->execute();
        $total = $stmt->fetch()['total'];

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as hoje FROM agendamentos WHERE TO_CHAR(data_agendamento, 'DD/MM/YYYY') = ? AND status = 'agendado'");
        $stmt->execute([$hoje]);
        $hoje_count = $stmt->fetch()['hoje'];

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as semana FROM agendamentos WHERE data_agendamento BETWEEN TO_DATE(?, 'DD/MM/YYYY') AND TO_DATE(?, 'DD/MM/YYYY') AND status = 'agendado'");
        $stmt->execute([$inicioSemana, $fimSemana]);
        $semana_count = $stmt->fetch()['semana'];

        return [
            'total' => $total,
            'hoje' => $hoje_count,
            'semana' => $semana_count
        ];
    }

    public function getProximosHorariosDisponiveis($dias = 5) {
        $horariosFixos = $this->getHorariosPorCategoria('EEG'); // Default to EEG for now

        $dayNamesPT = [
            'Monday' => 'Segunda-feira',
            'Tuesday' => 'Terça-feira',
            'Wednesday' => 'Quarta-feira',
            'Thursday' => 'Quinta-feira',
            'Friday' => 'Sexta-feira',
            'Saturday' => 'Sábado',
            'Sunday' => 'Domingo'
        ];

        $resultado = [];
        $dataAtual = new DateTime();
        $diasProcessados = 0;

        while ($diasProcessados < $dias) {
            $diaSemanaEn = $dataAtual->format('l');
            $dataFormatada = $dataAtual->format('d/m');
            $dataCompleta = $dataAtual->format('d/m/Y');

            if (isset($horariosFixos[$diaSemanaEn])) {
                $horariosDisponiveis = array_diff(
                    $horariosFixos[$diaSemanaEn],
                    $this->getHorariosOcupadosPorDia('EEG', $dataCompleta)
                );

                if (!empty($horariosDisponiveis)) {
                    $resultado[] = [
                        'dia' => $dayNamesPT[$diaSemanaEn],
                        'data' => $dataFormatada,
                        'horarios' => array_values($horariosDisponiveis)
                    ];
                }
                $diasProcessados++;
            }

            $dataAtual->add(new DateInterval('P1D'));
        }

        return $resultado;
    }

    private function getHorariosOcupadosPorDia($categoria, $dataAgendamento) {
        $stmt = $this->pdo->prepare("SELECT horario FROM agendamentos WHERE categoria_exame = ? AND TO_CHAR(data_agendamento, 'DD/MM/YYYY') = ? AND status = 'agendado'");
        $stmt->execute([$categoria, $dataAgendamento]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public function gerarTextoHorariosDisponiveis($dias = 5) {
        $horarios = $this->getProximosHorariosDisponiveis($dias);
        $texto = "Segue horários disponíveis atualizados :\n\n";

        foreach ($horarios as $dia) {
            $texto .= $dia['dia'] . ' ' . $dia['data'] . ': ';

            $horariosFormatados = array_map(function($horario) {
                return str_replace(':00', 'hs', $horario);
            }, $dia['horarios']);

            $texto .= implode(' - ', $horariosFormatados) . "\n";
        }

        return $texto;
    }

    public function atualizarStatusAgendamento($id, $status) {
        try {
            $stmt = $this->pdo->prepare("UPDATE agendamentos SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
            return ['success' => true, 'message' => 'Status atualizado com sucesso'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'Erro ao atualizar status: ' . $e->getMessage()];
        }
    }
}

class SQLiteAdapter implements IDatabaseAdapter {
    private $pdo;
    private $config;

    public function connect($config) {
        $this->config = $config;
        $this->pdo = new PDO("sqlite:{$config["dbname"]}");
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    public function createTables() {
        $sql = "CREATE TABLE IF NOT EXISTS agendamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome_paciente TEXT NOT NULL,
            ano_nascimento INTEGER NOT NULL,
            tipo_eeg TEXT,
            categoria_exame TEXT NOT NULL,
            tipo_exame_id INTEGER NOT NULL,
            data_agendamento TEXT NOT NULL,
            horario TEXT NOT NULL,
            data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'agendado',
            UNIQUE(categoria_exame, data_agendamento, horario)
        )";
        $this->pdo->exec($sql);

        $sql = "CREATE TABLE IF NOT EXISTS tipos_exames (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            categoria TEXT NOT NULL,
            nome TEXT NOT NULL,
            valor REAL NOT NULL,
            ativo BOOLEAN DEFAULT 1
        )";
        $this->pdo->exec($sql);

        $sql = "CREATE TABLE IF NOT EXISTS horarios_tipos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            categoria TEXT NOT NULL,
            dia_semana TEXT NOT NULL,
            horario TEXT NOT NULL,
            ativo BOOLEAN DEFAULT 1
        )";
        $this->pdo->exec($sql);

        $this->populateInitialData();
    }

    private function populateInitialData() {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM tipos_exames");
        $stmt->execute();
        if ($stmt->fetchColumn() > 0) {
            return;
        }

        $tiposExames = [
            ["EEG", "EEG Mapeamento", 240.00],
            ["EEG", "EEG Rotina", 120.00],
            ["EEG", "EEG Sono Vigília", 220.00],
            ["EEG", "EEG Concurso", 200.00],
            ["EEG", "EEG Infantil", 250.00],
            ["ENMG", "ENMG Membros Superiores", 180.00],
            ["ENMG", "ENMG Membros Inferiores", 180.00],
            ["ENMG", "ENMG Completo", 320.00],
            ["ENMG", "ENMG Face", 150.00],
            ["TC", "TC Crânio", 280.00],
            ["TC", "TC Tórax", 300.00],
            ["TC", "TC Abdome", 320.00],
            ["TC", "TC Coluna", 290.00],
            ["RM", "RM Crânio", 450.00],
            ["RM", "RM Coluna", 480.00],
            ["RM", "RM Joelho", 420.00],
            ["RM", "RM Abdome", 500.00],
            ["POLI", "Polissonografia Completa", 380.00],
            ["POLI", "Polissonografia Reduzida", 280.00]
        ];

        $stmt = $this->pdo->prepare("INSERT INTO tipos_exames (categoria, nome, valor) VALUES (?, ?, ?)");
        foreach ($tiposExames as $tipo) {
            $stmt->execute($tipo);
        }

        $horariosCategoria = [
            ["EEG", "Monday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Tuesday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Wednesday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Thursday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Friday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00"]],
            ["ENMG", "Monday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["ENMG", "Wednesday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["ENMG", "Friday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["TC", "Monday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Tuesday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Wednesday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Thursday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["RM", "Tuesday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["RM", "Thursday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["RM", "Saturday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["POLI", "Monday", ["20:00", "21:00"]],
            ["POLI", "Wednesday", ["20:00", "21:00"]]
        ];

        $stmt = $this->pdo->prepare("INSERT INTO horarios_tipos (categoria, dia_semana, horario) VALUES (?, ?, ?)");
        foreach ($horariosCategoria as $categoria) {
            $cat = $categoria[0];
            $dia = $categoria[1];
            $horarios = $categoria[2];

            foreach ($horarios as $horario) {
                $stmt->execute([$cat, $dia, $horario]);
            }
        }
    }

    public function getHorariosOcupados($categoria = null) {
        if ($categoria) {
            $stmt = $this->pdo->prepare("SELECT data_agendamento, horario FROM agendamentos WHERE categoria_exame = ? AND status = 'agendado'");
            $stmt->execute([$categoria]);
        } else {
            $stmt = $this->pdo->prepare("SELECT data_agendamento, horario, categoria_exame FROM agendamentos WHERE status = 'agendado'");
            $stmt->execute();
        }

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $horarios = [];
        foreach ($result as $row) {
            if ($categoria) {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'];
            } else {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'] . ' ' . $row['categoria_exame'];
            }
        }

        return $horarios;
    }

    public function agendarHorario($nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO agendamentos (nome_paciente, ano_nascimento, categoria_exame, tipo_exame_id, data_agendamento, horario, status) VALUES (?, ?, ?, ?, ?, ?, 'agendado')");
            $stmt->execute([$nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario]);

            $stmt = $this->pdo->prepare("SELECT nome, valor FROM tipos_exames WHERE id = ?");
            $stmt->execute([$tipoExameId]);
            $tipoExame = $stmt->fetch(PDO::FETCH_ASSOC);

            return [
                'success' => true,
                'message' => 'Agendamento realizado com sucesso',
                'tipo_exame_nome' => $tipoExame['nome'],
                'tipo_exame_valor' => $tipoExame['valor']
            ];
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // UNIQUE constraint failed for SQLite
                return ['success' => false, 'message' => 'Este horário já está ocupado para esta categoria'];
            }
            return ['success' => false, 'message' => 'Erro ao realizar agendamento: ' . $e->getMessage()];
        }
    }

    public function getAgendamentos($filtros = []) {
        $sql = "SELECT a.*, te.nome as tipo_exame_nome, te.valor FROM agendamentos a JOIN tipos_exames te ON a.tipo_exame_id = te.id WHERE 1=1";
        $params = [];

        if (!empty($filtros['data'])) {
            $sql .= " AND a.data_agendamento = ?";
            $params[] = $filtros['data'];
        }

        if (!empty($filtros['tipo_exame_id'])) {
            $sql .= " AND a.tipo_exame_id = ?";
            $params[] = $filtros['tipo_exame_id'];
        }

        if (!empty($filtros['categoria'])) {
            $sql .= " AND a.categoria_exame = ?";
            $params[] = $filtros['categoria'];
        }

        if (!empty($filtros['paciente'])) {
            $sql .= " AND a.nome_paciente LIKE ?";
            $params[] = '%' . $filtros['paciente'] . '%';
        }

        if (!empty($filtros['status'])) {
            $sql .= " AND a.status = ?";
            $params[] = $filtros['status'];
        }

        $sql .= " ORDER BY a.data_agendamento, a.horario";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getCategorias() {
        $stmt = $this->pdo->prepare("SELECT DISTINCT categoria FROM tipos_exames WHERE ativo = 1 ORDER BY categoria");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public function getTiposPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT id, nome, valor FROM tipos_exames WHERE categoria = ? AND ativo = 1 ORDER BY nome");
        $stmt->execute([$categoria]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getHorariosPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT dia_semana, horario FROM horarios_tipos WHERE categoria = ? AND ativo = 1 ORDER BY dia_semana, horario");
        $stmt->execute([$categoria]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $horarios = [];
        foreach ($result as $row) {
            if (!isset($horarios[$row['dia_semana']])) {
                $horarios[$row['dia_semana']] = [];
            }
            $horarios[$row['dia_semana']][] = $row['horario'];
        }

        return $horarios;
    }

    public function verificarDisponibilidade($categoriaExame, $dataAgendamento, $horario) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM agendamentos WHERE categoria_exame = ? AND data_agendamento = ? AND horario = ? AND status = 'agendado'");
        $stmt->execute([$categoriaExame, $dataAgendamento, $horario]);
        $result = $stmt->fetch();

        return $result['count'] == 0;
    }

    public function getEstatisticas() {
        $hoje = date('d/m/Y');
        $inicioSemana = date('d/m/Y', strtotime('monday this week'));
        $fimSemana = date('d/m/Y', strtotime('sunday this week'));

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total FROM agendamentos");
        $stmt->execute();
        $total = $stmt->fetch()['total'];

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as hoje FROM agendamentos WHERE data_agendamento = ? AND status = 'agendado'");
        $stmt->execute([$hoje]);
        $hoje_count = $stmt->fetch()['hoje'];

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as semana FROM agendamentos WHERE STRFTIME('%J', SUBSTR(data_agendamento, 7, 4) || '-' || SUBSTR(data_agendamento, 4, 2) || '-' || SUBSTR(data_agendamento, 1, 2)) BETWEEN STRFTIME('%J', SUBSTR(?, 7, 4) || '-' || SUBSTR(?, 4, 2) || '-' || SUBSTR(?, 1, 2)) AND STRFTIME('%J', SUBSTR(?, 7, 4) || '-' || SUBSTR(?, 4, 2) || '-' || SUBSTR(?, 1, 2)) AND status = 'agendado'");
        $stmt->execute([$inicioSemana, $inicioSemana, $inicioSemana, $fimSemana, $fimSemana, $fimSemana]);
        $semana_count = $stmt->fetch()['semana'];

        return [
            'total' => $total,
            'hoje' => $hoje_count,
            'semana' => $semana_count
        ];
    }

    public function getProximosHorariosDisponiveis($dias = 5) {
        $horariosFixos = $this->getHorariosPorCategoria('EEG'); // Default to EEG for now

        $dayNamesPT = [
            'Monday' => 'Segunda-feira',
            'Tuesday' => 'Terça-feira',
            'Wednesday' => 'Quarta-feira',
            'Thursday' => 'Quinta-feira',
            'Friday' => 'Sexta-feira',
            'Saturday' => 'Sábado',
            'Sunday' => 'Domingo'
        ];

        $resultado = [];
        $dataAtual = new DateTime();
        $diasProcessados = 0;

        while ($diasProcessados < $dias) {
            $diaSemanaEn = $dataAtual->format('l');
            $dataFormatada = $dataAtual->format('d/m');
            $dataCompleta = $dataAtual->format('d/m/Y');

            if (isset($horariosFixos[$diaSemanaEn])) {
                $horariosDisponiveis = array_diff(
                    $horariosFixos[$diaSemanaEn],
                    $this->getHorariosOcupadosPorDia('EEG', $dataCompleta)
                );

                if (!empty($horariosDisponiveis)) {
                    $resultado[] = [
                        'dia' => $dayNamesPT[$diaSemanaEn],
                        'data' => $dataFormatada,
                        'horarios' => array_values($horariosDisponiveis)
                    ];
                }
                $diasProcessados++;
            }

            $dataAtual->add(new DateInterval('P1D'));
        }

        return $resultado;
    }

    private function getHorariosOcupadosPorDia($categoria, $dataAgendamento) {
        $stmt = $this->pdo->prepare("SELECT horario FROM agendamentos WHERE categoria_exame = ? AND data_agendamento = ? AND status = 'agendado'");
        $stmt->execute([$categoria, $dataAgendamento]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public function gerarTextoHorariosDisponiveis($dias = 5) {
        $horarios = $this->getProximosHorariosDisponiveis($dias);
        $texto = "Segue horários disponíveis atualizados :\n\n";

        foreach ($horarios as $dia) {
            $texto .= $dia['dia'] . ' ' . $dia['data'] . ': ';

            $horariosFormatados = array_map(function($horario) {
                return str_replace(':00', 'hs', $horario);
            }, $dia['horarios']);

            $texto .= implode(' - ', $horariosFormatados) . "\n";
        }

        return $texto;
    }

    public function atualizarStatusAgendamento($id, $status) {
        try {
            $stmt = $this->pdo->prepare("UPDATE agendamentos SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
            return ['success' => true, 'message' => 'Status atualizado com sucesso'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'Erro ao atualizar status: ' . $e->getMessage()];
        }
    }
}

class FirebirdAdapter implements IDatabaseAdapter {
    private $pdo;
    private $config;

    public function connect($config) {
        $this->config = $config;
        $dsn = "firebird:dbname={$config["host"]}/{$config["port"]}:{$config["dbname"]};charset={$config["charset"]}";
        $this->pdo = new PDO($dsn, $config["username"], $config["password"]);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    public function createTables() {
        // Firebird does not support IF NOT EXISTS for CREATE TABLE directly in PDO
        // Need to check existence first or handle exceptions
        try {
            $this->pdo->exec("CREATE TABLE agendamentos (
                id INTEGER PRIMARY KEY,
                nome_paciente VARCHAR(255) NOT NULL,
                ano_nascimento INTEGER NOT NULL,
                tipo_eeg VARCHAR(255),
                categoria_exame VARCHAR(50) NOT NULL,
                tipo_exame_id INTEGER NOT NULL,
                data_agendamento VARCHAR(10) NOT NULL,
                horario VARCHAR(5) NOT NULL,
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status VARCHAR(20) DEFAULT 'agendado'
            )");
            $this->pdo->exec("CREATE UNIQUE INDEX unique_agendamento ON agendamentos (categoria_exame, data_agendamento, horario)");
        } catch (PDOException $e) {
            // Table already exists, ignore
            if ($e->getCode() != '42S01') { // '42S01' is SQLSTATE for table already exists
                throw $e;
            }
        }

        try {
            $this->pdo->exec("CREATE TABLE tipos_exames (
                id INTEGER PRIMARY KEY,
                categoria VARCHAR(50) NOT NULL,
                nome VARCHAR(255) NOT NULL,
                valor DECIMAL(10,2) NOT NULL,
                ativo BOOLEAN DEFAULT TRUE
            )");
        } catch (PDOException $e) {
            if ($e->getCode() != '42S01') {
                throw $e;
            }
        }

        try {
            $this->pdo->exec("CREATE TABLE horarios_tipos (
                id INTEGER PRIMARY KEY,
                categoria VARCHAR(50) NOT NULL,
                dia_semana VARCHAR(20) NOT NULL,
                horario VARCHAR(5) NOT NULL,
                ativo BOOLEAN DEFAULT TRUE
            )");
        } catch (PDOException $e) {
            if ($e->getCode() != '42S01') {
                throw $e;
            }
        }

        $this->populateInitialData();
    }

    private function populateInitialData() {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM tipos_exames");
        $stmt->execute();
        if ($stmt->fetchColumn() > 0) {
            return;
        }

        $tiposExames = [
            ["EEG", "EEG Mapeamento", 240.00],
            ["EEG", "EEG Rotina", 120.00],
            ["EEG", "EEG Sono Vigília", 220.00],
            ["EEG", "EEG Concurso", 200.00],
            ["EEG", "EEG Infantil", 250.00],
            ["ENMG", "ENMG Membros Superiores", 180.00],
            ["ENMG", "ENMG Membros Inferiores", 180.00],
            ["ENMG", "ENMG Completo", 320.00],
            ["ENMG", "ENMG Face", 150.00],
            ["TC", "TC Crânio", 280.00],
            ["TC", "TC Tórax", 300.00],
            ["TC", "TC Abdome", 320.00],
            ["TC", "TC Coluna", 290.00],
            ["RM", "RM Crânio", 450.00],
            ["RM", "RM Coluna", 480.00],
            ["RM", "RM Joelho", 420.00],
            ["RM", "RM Abdome", 500.00],
            ["POLI", "Polissonografia Completa", 380.00],
            ["POLI", "Polissonografia Reduzida", 280.00]
        ];

        $stmt = $this->pdo->prepare("INSERT INTO tipos_exames (categoria, nome, valor) VALUES (?, ?, ?)");
        foreach ($tiposExames as $tipo) {
            $stmt->execute($tipo);
        }

        $horariosCategoria = [
            ["EEG", "Monday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Tuesday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Wednesday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Thursday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"]],
            ["EEG", "Friday", ["08:00", "08:30", "13:00", "13:30", "14:00", "14:30", "15:00"]],
            ["ENMG", "Monday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["ENMG", "Wednesday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["ENMG", "Friday", ["08:00", "09:00", "10:00", "14:00", "15:00", "16:00"]],
            ["TC", "Monday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Tuesday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Wednesday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["TC", "Thursday", ["07:00", "08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"]],
            ["RM", "Tuesday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["RM", "Thursday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["RM", "Saturday", ["08:00", "09:30", "11:00", "14:00", "15:30", "17:00"]],
            ["POLI", "Monday", ["20:00", "21:00"]],
            ["POLI", "Wednesday", ["20:00", "21:00"]]
        ];

        $stmt = $this->pdo->prepare("INSERT INTO horarios_tipos (categoria, dia_semana, horario) VALUES (?, ?, ?)");
        foreach ($horariosCategoria as $categoria) {
            $cat = $categoria[0];
            $dia = $categoria[1];
            $horarios = $categoria[2];

            foreach ($horarios as $horario) {
                $stmt->execute([$cat, $dia, $horario]);
            }
        }
    }

    public function getHorariosOcupados($categoria = null) {
        if ($categoria) {
            $stmt = $this->pdo->prepare("SELECT data_agendamento, horario FROM agendamentos WHERE categoria_exame = ? AND status = 'agendado'");
            $stmt->execute([$categoria]);
        } else {
            $stmt = $this->pdo->prepare("SELECT data_agendamento, horario, categoria_exame FROM agendamentos WHERE status = 'agendado'");
            $stmt->execute();
        }

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $horarios = [];
        foreach ($result as $row) {
            if ($categoria) {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'];
            } else {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'] . ' ' . $row['categoria_exame'];
            }
        }

        return $horarios;
    }

    public function agendarHorario($nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO agendamentos (nome_paciente, ano_nascimento, categoria_exame, tipo_exame_id, data_agendamento, horario, status) VALUES (?, ?, ?, ?, ?, ?, 'agendado')");
            $stmt->execute([$nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario]);

            $stmt = $this->pdo->prepare("SELECT nome, valor FROM tipos_exames WHERE id = ?");
            $stmt->execute([$tipoExameId]);
            $tipoExame = $stmt->fetch(PDO::FETCH_ASSOC);

            return [
                'success' => true,
                'message' => 'Agendamento realizado com sucesso',
                'tipo_exame_nome' => $tipoExame['nome'],
                'tipo_exame_valor' => $tipoExame['valor']
            ];
        } catch (PDOException $e) {
            if ($e->getCode() == '23000') { // UNIQUE constraint failed for Firebird (SQLSTATE 23000)
                return ['success' => false, 'message' => 'Este horário já está ocupado para esta categoria'];
            }
            return ['success' => false, 'message' => 'Erro ao realizar agendamento: ' . $e->getMessage()];
        }
    }

    public function getAgendamentos($filtros = []) {
        $sql = "SELECT a.*, te.nome as tipo_exame_nome, te.valor FROM agendamentos a JOIN tipos_exames te ON a.tipo_exame_id = te.id WHERE 1=1";
        $params = [];

        if (!empty($filtros['data'])) {
            $sql .= " AND a.data_agendamento = ?";
            $params[] = $filtros['data'];
        }

        if (!empty($filtros['tipo_exame_id'])) {
            $sql .= " AND a.tipo_exame_id = ?";
            $params[] = $filtros['tipo_exame_id'];
        }

        if (!empty($filtros['categoria'])) {
            $sql .= " AND a.categoria_exame = ?";
            $params[] = $filtros['categoria'];
        }

        if (!empty($filtros['paciente'])) {
            $sql .= " AND a.nome_paciente CONTAINING ?"; // Firebird uses CONTAINING for LIKE
            $params[] = $filtros['paciente'];
        }

        if (!empty($filtros['status'])) {
            $sql .= " AND a.status = ?";
            $params[] = $filtros['status'];
        }

        $sql .= " ORDER BY a.data_agendamento, a.horario";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getCategorias() {
        $stmt = $this->pdo->prepare("SELECT DISTINCT categoria FROM tipos_exames WHERE ativo = TRUE ORDER BY categoria");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public function getTiposPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT id, nome, valor FROM tipos_exames WHERE categoria = ? AND ativo = TRUE ORDER BY nome");
        $stmt->execute([$categoria]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getHorariosPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT dia_semana, horario FROM horarios_tipos WHERE categoria = ? AND ativo = TRUE ORDER BY dia_semana, horario");
        $stmt->execute([$categoria]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $horarios = [];
        foreach ($result as $row) {
            if (!isset($horarios[$row['dia_semana']])) {
                $horarios[$row['dia_semana']] = [];
            }
            $horarios[$row['dia_semana']][] = $row['horario'];
        }

        return $horarios;
    }

    public function verificarDisponibilidade($categoriaExame, $dataAgendamento, $horario) {
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as count FROM agendamentos WHERE categoria_exame = ? AND data_agendamento = ? AND horario = ? AND status = 'agendado'");
        $stmt->execute([$categoriaExame, $dataAgendamento, $horario]);
        $result = $stmt->fetch();

        return $result['count'] == 0;
    }

    public function getEstatisticas() {
        $hoje = date('d/m/Y');
        $inicioSemana = date('d/m/Y', strtotime('monday this week'));
        $fimSemana = date('d/m/Y', strtotime('sunday this week'));

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total FROM agendamentos");
        $stmt->execute();
        $total = $stmt->fetch()['total'];

        $stmt = $this->pdo->prepare("SELECT COUNT(*) as hoje FROM agendamentos WHERE data_agendamento = ? AND status = 'agendado'");
        $stmt->execute([$hoje]);
        $hoje_count = $stmt->fetch()['hoje'];

        // Firebird date functions might differ, using simple string comparison for now
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as semana FROM agendamentos WHERE data_agendamento >= ? AND data_agendamento <= ? AND status = 'agendado'");
        $stmt->execute([$inicioSemana, $fimSemana]);
        $semana_count = $stmt->fetch()['semana'];

        return [
            'total' => $total,
            'hoje' => $hoje_count,
            'semana' => $semana_count
        ];
    }

    public function getProximosHorariosDisponiveis($dias = 5) {
        $horariosFixos = $this->getHorariosPorCategoria('EEG'); // Default to EEG for now

        $dayNamesPT = [
            'Monday' => 'Segunda-feira',
            'Tuesday' => 'Terça-feira',
            'Wednesday' => 'Quarta-feira',
            'Thursday' => 'Quinta-feira',
            'Friday' => 'Sexta-feira',
            'Saturday' => 'Sábado',
            'Sunday' => 'Domingo'
        ];

        $resultado = [];
        $dataAtual = new DateTime();
        $diasProcessados = 0;

        while ($diasProcessados < $dias) {
            $diaSemanaEn = $dataAtual->format('l');
            $dataFormatada = $dataAtual->format('d/m');
            $dataCompleta = $dataAtual->format('d/m/Y');

            if (isset($horariosFixos[$diaSemanaEn])) {
                $horariosDisponiveis = array_diff(
                    $horariosFixos[$diaSemanaEn],
                    $this->getHorariosOcupadosPorDia('EEG', $dataCompleta)
                );

                if (!empty($horariosDisponiveis)) {
                    $resultado[] = [
                        'dia' => $dayNamesPT[$diaSemanaEn],
                        'data' => $dataFormatada,
                        'horarios' => array_values($horariosDisponiveis)
                    ];
                }
                $diasProcessados++;
            }

            $dataAtual->add(new DateInterval('P1D'));
        }

        return $resultado;
    }

    private function getHorariosOcupadosPorDia($categoria, $dataAgendamento) {
        $stmt = $this->pdo->prepare("SELECT horario FROM agendamentos WHERE categoria_exame = ? AND data_agendamento = ? AND status = 'agendado'");
        $stmt->execute([$categoria, $dataAgendamento]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public function gerarTextoHorariosDisponiveis($dias = 5) {
        $horarios = $this->getProximosHorariosDisponiveis($dias);
        $texto = "Segue horários disponíveis atualizados :\n\n";

        foreach ($horarios as $dia) {
            $texto .= $dia['dia'] . ' ' . $dia['data'] . ': ';

            $horariosFormatados = array_map(function($horario) {
                return str_replace(':00', 'hs', $horario);
            }, $dia['horarios']);

            $texto .= implode(' - ', $horariosFormatados) . "\n";
        }

        return $texto;
    }

    public function atualizarStatusAgendamento($id, $status) {
        try {
            $stmt = $this->pdo->prepare("UPDATE agendamentos SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
            return ['success' => true, 'message' => 'Status atualizado com sucesso'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'Erro ao atualizar status: ' . $e->getMessage()];
        }
    }
}

class DatabaseManager {
    private $adapter;

    public function __construct($dbType, $config) {
        switch ($dbType) {
            case 'mysql':
                $this->adapter = new MySQLAdapter();
                break;
            case 'pgsql':
                $this->adapter = new PostgreSQLAdapter();
                break;
            case 'sqlite':
                $this->adapter = new SQLiteAdapter();
                break;
            case 'firebird':
                $this->adapter = new FirebirdAdapter();
                break;
            default:
                throw new Exception('Tipo de banco de dados não suportado: ' . $dbType);
        }
        $this->adapter->connect($config);
    }

    public function __call($method, $args) {
        if (method_exists($this->adapter, $method)) {
            return call_user_func_array([$this->adapter, $method], $args);
        }
        throw new Exception('Método não encontrado no adaptador: ' . $method);
    }
}

?>

