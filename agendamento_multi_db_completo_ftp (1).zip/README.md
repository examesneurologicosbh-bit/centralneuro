# Sistema de Agendamento Multi-Exames e Multi-Banco de Dados

Este projeto é um sistema de agendamento completo, desenvolvido em PHP e JavaScript, com suporte a múltiplos tipos de exames e a capacidade de se conectar a diferentes sistemas de gerenciamento de banco de dados (MySQL, SQLite, PostgreSQL, Firebird).

## Funcionalidades Principais:

- **Página de Instalação Online (`install.php`):** Permite configurar a conexão com o banco de dados e criar as tabelas necessárias de forma interativa. Suporta MySQL, SQLite, PostgreSQL e Firebird. Inclui credenciais de exemplo para facilitar a configuração.
- **Sistema de Agendamento (`index.html`):** Interface amigável para os pacientes agendarem exames. Permite selecionar a categoria e o tipo específico do exame, visualizar horários disponíveis dinamicamente e agendar. Integração com WhatsApp para envio de confirmação.
- **Painel Administrativo (`admin.html`):** Dashboard completo para gerenciar agendamentos. Inclui estatísticas, filtros avançados por data, categoria, tipo de exame, paciente e status. Permite alterar o status dos agendamentos e exportar dados para CSV. Possui uma funcionalidade para gerar texto dos horários disponíveis para envio rápido.
- **API RESTful (`api.php`):** Backend robusto que gerencia todas as operações de agendamento, consulta de horários, tipos de exames e estatísticas. Utiliza uma camada de abstração de banco de dados para garantir compatibilidade com diferentes SGBDs.
- **Camada de Abstração de Banco de Dados (`DatabaseManager.php`):** Classe responsável por abstrair as operações de banco de dados, permitindo que o sistema funcione com diferentes drivers (PDO para MySQL, SQLite, PostgreSQL e Firebird).
- **Configuração Centralizada (`config.php`):** Arquivo que armazena as configurações do banco de dados (preenchido pelo `install.php`), configurações de exames (categorias, tipos e horários fixos) e outras variáveis globais.

## Estrutura do Projeto:

```
. 
├── admin.html             # Painel administrativo
├── api.php                # API RESTful do sistema
├── config.php             # Arquivo de configuração (gerado pelo install.php)
├── DatabaseManager.php    # Camada de abstração de banco de dados
├── install.php            # Página de instalação online
├── index.html             # Página de agendamento para pacientes
├── README.md              # Este arquivo
├── agendamentos.db        # Exemplo de banco de dados SQLite (se usado)
└── ...                    # Outros arquivos e diretórios (horarios.txt, migrate_data.php, etc.)
```

## Como Instalar e Usar:

1.  **Faça o upload** de todos os arquivos e diretórios para o seu servidor web (ex: `public_html` ou `htdocs`).
2.  **Acesse a página de instalação** no seu navegador: `http://seusite.com/install.php` (substitua `seusite.com` pelo seu domínio).
3.  Na página de instalação, **selecione o tipo de banco de dados** que você deseja usar (MySQL, SQLite, PostgreSQL, Firebird).
4.  **Preencha os dados de conexão** com o seu banco de dados. As credenciais de exemplo fornecidas podem ser úteis para testes.
5.  Clique em **"Instalar Sistema"**. O script irá testar a conexão, criar as tabelas necessárias e gerar o arquivo `config.php`.
6.  Após a instalação bem-sucedida, você pode acessar:
    *   **Página de Agendamento:** `http://seusite.com/index.html`
    *   **Painel Administrativo:** `http://seusite.com/admin.html`

## Requisitos:

- Servidor web (Apache, Nginx, etc.)
- PHP 7.4 ou superior
- Extensões PHP para o banco de dados escolhido (ex: `php-pdo`, `php-mysql`, `php-sqlite3`, `php-pgsql`, `php-interbase` para Firebird)

## Observações:

- O arquivo `agendamentos.db` é um exemplo de banco de dados SQLite e será criado automaticamente se você selecionar SQLite durante a instalação.
- As configurações de exames e horários fixos são definidas no `config.php`. Para personalizá-las, você pode editar este arquivo diretamente ou implementar uma interface administrativa para isso.

---

