<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação - Sistema de Agendamento Multi-Exames</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            padding: 40px;
            max-width: 700px;
            width: 100%;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #333;
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        .header p {
            color: #666;
            font-size: 1.1em;
        }

        .step {
            margin-bottom: 30px;
            padding: 20px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            background: #f9f9f9;
        }

        .step h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 1.3em;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        input[type="text"],
        input[type="password"],
        input[type="number"],
        select {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1em;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus,
        input[type="number"]:focus,
        select:focus {
            outline: none;
            border-color: #667eea;
        }

        small {
            color: #666;
            font-size: 0.9em;
            display: block;
            margin-top: 5px;
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s ease;
            width: 100%;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .btn:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
        }

        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .message.info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .progress {
            width: 100%;
            height: 20px;
            background: #e0e0e0;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 20px;
        }

        .progress-bar {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            width: 0%;
            transition: width 0.3s ease;
        }

        .credentials-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }

        @media (max-width: 600px) {
            .credentials-grid {
                grid-template-columns: 1fr;
            }
        }

        .credential-card {
            background: #f0f8ff;
            border: 1px solid #b3d9ff;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
        }

        .credential-card h4 {
            color: #0066cc;
            margin-bottom: 10px;
        }

        .credential-card p {
            font-size: 0.9em;
            color: #333;
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏥 Instalação do Sistema</h1>
            <p>Sistema de Agendamento Multi-Exames com Suporte a Múltiplos Bancos de Dados</p>
        </div>

        <div class="progress">
            <div class="progress-bar" id="progressBar"></div>
        </div>

        <?php if (isset($_POST['install'])): ?>
            <?php
            $db_type = $_POST['db_type'];
            $db_host = $_POST['db_host'];
            $db_port = $_POST['db_port'] ?: '';
            $db_name = $_POST['db_name'];
            $db_user = $_POST['db_user'];
            $db_pass = $_POST['db_pass'];
            $db_charset = $_POST['db_charset'] ?: 'utf8mb4';

            try {
                // Criar arquivo de configuração
                $config_content = "<?php\n";
                $config_content .= "// Configurações do Banco de Dados\n";
                $config_content .= "define('DB_TYPE', '$db_type');\n";
                $config_content .= "define('DB_HOST', '$db_host');\n";
                $config_content .= "define('DB_PORT', '$db_port');\n";
                $config_content .= "define('DB_NAME', '$db_name');\n";
                $config_content .= "define('DB_USER', '$db_user');\n";
                $config_content .= "define('DB_PASS', '$db_pass');\n";
                $config_content .= "define('DB_CHARSET', '$db_charset');\n\n";
                
                $config_content .= "// Configurações de Exames e Horários\n";
                $config_content .= "\$GLOBALS['EXAMS_CONFIG'] = [\n";
                $config_content .= "    'EEG' => [\n";
                $config_content .= "        'tipos' => [\n";
                $config_content .= "            ['id' => 1, 'nome' => 'EEG de Rotina', 'valor' => 250.00],\n";
                $config_content .= "            ['id' => 2, 'nome' => 'EEG com Mapeamento', 'valor' => 350.00]\n";
                $config_content .= "        ],\n";
                $config_content .= "        'horarios' => [\n";
                $config_content .= "            'Monday' => ['08:00', '09:00', '10:00', '13:00', '14:00', '15:00'],\n";
                $config_content .= "            'Tuesday' => ['08:00', '09:00', '10:00', '13:00', '14:00', '15:00'],\n";
                $config_content .= "            'Wednesday' => ['08:00', '09:00', '10:00', '13:00', '14:00', '15:00'],\n";
                $config_content .= "            'Thursday' => ['08:00', '09:00', '10:00', '13:00', '14:00', '15:00'],\n";
                $config_content .= "            'Friday' => ['08:00', '09:00', '10:00', '13:00', '14:00', '15:00']\n";
                $config_content .= "        ]\n";
                $config_content .= "    ],\n";
                $config_content .= "    'ENMG' => [\n";
                $config_content .= "        'tipos' => [\n";
                $config_content .= "            ['id' => 3, 'nome' => 'Eletroneuromiografia de Membros Superiores', 'valor' => 400.00],\n";
                $config_content .= "            ['id' => 4, 'nome' => 'Eletroneuromiografia de Membros Inferiores', 'valor' => 400.00]\n";
                $config_content .= "        ],\n";
                $config_content .= "        'horarios' => [\n";
                $config_content .= "            'Monday' => ['16:00', '17:00'],\n";
                $config_content .= "            'Wednesday' => ['16:00', '17:00']\n";
                $config_content .= "        ]\n";
                $config_content .= "    ],\n";
                $config_content .= "    'POLI' => [\n";
                $config_content .= "        'tipos' => [\n";
                $config_content .= "            ['id' => 5, 'nome' => 'Polissonografia Domiciliar', 'valor' => 800.00]\n";
                $config_content .= "        ],\n";
                $config_content .= "        'horarios' => [\n";
                $config_content .= "            'Tuesday' => ['18:00', '19:00'],\n";
                $config_content .= "            'Thursday' => ['18:00', '19:00']\n";
                $config_content .= "        ]\n";
                $config_content .= "    ]\n";
                $config_content .= "];\n\n";
                
                $config_content .= "// Número de WhatsApp para contato\n";
                $config_content .= "define('WHATSAPP_NUMBER', '553130581685');\n\n";
                
                $config_content .= "// Status de agendamento\n";
                $config_content .= "define('STATUS_AGENDADO', 'agendado');\n";
                $config_content .= "define('STATUS_REALIZADO', 'realizado');\n";
                $config_content .= "define('STATUS_CANCELADO', 'cancelado');\n\n";
                
                $config_content .= "// Dias da semana em português para exibição\n";
                $config_content .= "\$GLOBALS['DAY_NAMES_PT'] = [\n";
                $config_content .= "    'Sunday' => 'Domingo',\n";
                $config_content .= "    'Monday' => 'Segunda-feira',\n";
                $config_content .= "    'Tuesday' => 'Terça-feira',\n";
                $config_content .= "    'Wednesday' => 'Quarta-feira',\n";
                $config_content .= "    'Thursday' => 'Quinta-feira',\n";
                $config_content .= "    'Friday' => 'Sexta-feira',\n";
                $config_content .= "    'Saturday' => 'Sábado'\n";
                $config_content .= "];\n";
                $config_content .= "?>";

                file_put_contents('config.php', $config_content);

                // Testar conexão e criar tabelas
                require_once 'DatabaseManager.php';
                $dbManager = new DatabaseManager();
                
                if ($dbManager->testConnection()) {
                    $dbManager->createTables();
                    $dbManager->insertInitialData();
                    
                    echo '<div class="message success">✅ Instalação concluída com sucesso!</div>';
                    echo '<div class="message info">📋 O arquivo config.php foi criado e as tabelas foram configuradas no banco de dados.</div>';
                    echo '<div class="message info">🚀 Você pode agora acessar o sistema através do <a href="index.html">painel de agendamento</a> ou do <a href="admin.html">painel administrativo</a>.</div>';
                } else {
                    echo '<div class="message error">❌ Erro ao conectar com o banco de dados. Verifique as configurações.</div>';
                }
            } catch (Exception $e) {
                echo '<div class="message error">❌ Erro durante a instalação: ' . $e->getMessage() . '</div>';
            }
            ?>
        <?php else: ?>

        <form method="POST" id="installForm">
            <div class="step">
                <h3>📊 Configuração do Banco de Dados</h3>
                
                <div class="form-group">
                    <label for="db_type">Tipo de Banco de Dados:</label>
                    <select id="db_type" name="db_type" required onchange="updatePortPlaceholder()">
                        <option value="mysql">MySQL / MariaDB</option>
                        <option value="sqlite">SQLite</option>
                        <option value="pgsql">PostgreSQL</option>
                        <option value="firebird">Firebird</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="db_host">Host do Banco de Dados:</label>
                    <input type="text" id="db_host" name="db_host" value="mysql.examesneurologicos.com.br" required>
                    <small>Host alternativo: mysql63-farm2.uni5.net</small>
                </div>

                <div class="form-group">
                    <label for="db_port">Porta (opcional):</label>
                    <input type="number" id="db_port" name="db_port" placeholder="3306 (MySQL), 5432 (PostgreSQL), 3050 (Firebird)">
                </div>

                <div class="form-group">
                    <label for="db_name">Nome do Banco de Dados:</label>
                    <select id="db_name_select" name="db_name_select" onchange="updateDbName()">
                        <option value="">Selecione um banco ou digite manualmente</option>
                        <option value="examesne06_add1">examesne06_add1</option>
                        <option value="examesne01_add1">examesne01_add1</option>
                        <option value="examesne02_add1">examesne02_add1</option>
                        <option value="examesne04_add1">examesne04_add1</option>
                        <option value="custom">Outro (digite abaixo)</option>
                    </select>
                    <input type="text" id="db_name" name="db_name" value="examesneurolog" required style="margin-top: 10px;">
                </div>

                <div class="form-group">
                    <label for="db_user">Usuário:</label>
                    <select id="db_user_select" name="db_user_select" onchange="updateDbUser()">
                        <option value="">Selecione um usuário ou digite manualmente</option>
                        <option value="examesne06_add1">examesne06_add1</option>
                        <option value="examesne01_add1">examesne01_add1</option>
                        <option value="examesne02_add1">examesne02_add1</option>
                        <option value="examesne04_add1">examesne04_add1</option>
                        <option value="custom">Outro (digite abaixo)</option>
                    </select>
                    <input type="text" id="db_user" name="db_user" value="examesneurolog" required style="margin-top: 10px;">
                </div>

                <div class="form-group">
                    <label for="db_pass">Senha:</label>
                    <select id="db_pass_select" name="db_pass_select" onchange="updateDbPass()">
                        <option value="">Selecione uma senha ou digite manualmente</option>
                        <option value="gfHFDDF445ff35">gfHFDDF445ff35</option>
                        <option value="FFet63gehj788">FFet63gehj788</option>
                        <option value="ZxAimBNF4wxatA9">ZxAimBNF4wxatA9</option>
                        <option value="custom">Outra (digite abaixo)</option>
                    </select>
                    <input type="password" id="db_pass" name="db_pass" value="FRED4321" required style="margin-top: 10px;">
                </div>

                <div class="form-group">
                    <label for="db_charset">Charset (opcional):</label>
                    <select id="db_charset" name="db_charset">
                        <option value="utf8mb4">utf8mb4 (recomendado)</option>
                        <option value="utf8">utf8</option>
                        <option value="latin1">latin1</option>
                    </select>
                </div>
            </div>

            <div class="step">
                <h3>🔧 Credenciais de Exemplo Disponíveis</h3>
                <div class="credentials-grid">
                    <div class="credential-card">
                        <h4>Banco 01</h4>
                        <p><strong>DB:</strong> examesne01_add1</p>
                        <p><strong>User:</strong> examesne01_add1</p>
                        <p><strong>Pass:</strong> FFet63gehj788</p>
                    </div>
                    <div class="credential-card">
                        <h4>Banco 02</h4>
                        <p><strong>DB:</strong> examesne02_add1</p>
                        <p><strong>User:</strong> examesne02_add1</p>
                        <p><strong>Pass:</strong> ZxAimBNF4wxatA9</p>
                    </div>
                    <div class="credential-card">
                        <h4>Banco 04</h4>
                        <p><strong>DB:</strong> examesne04_add1</p>
                        <p><strong>User:</strong> examesne04_add1</p>
                        <p><strong>Pass:</strong> gfHFDDF445ff35</p>
                    </div>
                    <div class="credential-card">
                        <h4>Banco 06</h4>
                        <p><strong>DB:</strong> examesne06_add1</p>
                        <p><strong>User:</strong> examesne06_add1</p>
                        <p><strong>Pass:</strong> gfHFDDF445ff35</p>
                    </div>
                </div>
            </div>

            <button type="submit" name="install" class="btn">🚀 Instalar Sistema</button>
        </form>

        <?php endif; ?>
    </div>

    <script>
        function updatePortPlaceholder() {
            const dbType = document.getElementById('db_type').value;
            const portInput = document.getElementById('db_port');
            
            switch(dbType) {
                case 'mysql':
                    portInput.placeholder = '3306 (padrão MySQL)';
                    break;
                case 'pgsql':
                    portInput.placeholder = '5432 (padrão PostgreSQL)';
                    break;
                case 'firebird':
                    portInput.placeholder = '3050 (padrão Firebird)';
                    break;
                case 'sqlite':
                    portInput.placeholder = 'Não aplicável para SQLite';
                    portInput.disabled = true;
                    break;
                default:
                    portInput.placeholder = 'Porta do banco de dados';
                    portInput.disabled = false;
            }
        }

        function updateDbName() {
            const select = document.getElementById('db_name_select');
            const input = document.getElementById('db_name');
            
            if (select.value && select.value !== 'custom') {
                input.value = select.value;
            } else if (select.value === 'custom') {
                input.value = '';
                input.focus();
            }
        }

        function updateDbUser() {
            const select = document.getElementById('db_user_select');
            const input = document.getElementById('db_user');
            
            if (select.value && select.value !== 'custom') {
                input.value = select.value;
            } else if (select.value === 'custom') {
                input.value = '';
                input.focus();
            }
        }

        function updateDbPass() {
            const select = document.getElementById('db_pass_select');
            const input = document.getElementById('db_pass');
            
            if (select.value && select.value !== 'custom') {
                input.value = select.value;
            } else if (select.value === 'custom') {
                input.value = '';
                input.focus();
            }
        }

        // Simular progresso durante o envio do formulário
        document.getElementById('installForm').addEventListener('submit', function() {
            const progressBar = document.getElementById('progressBar');
            let progress = 0;
            
            const interval = setInterval(() => {
                progress += 10;
                progressBar.style.width = progress + '%';
                
                if (progress >= 100) {
                    clearInterval(interval);
                }
            }, 200);
        });

        // Inicializar placeholder da porta
        updatePortPlaceholder();
    </script>
</body>
</html>

