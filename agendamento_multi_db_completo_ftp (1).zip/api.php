<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER["REQUEST_METHOD"] == "OPTIONS") {
    exit(0);
}

require_once "database.php";

$db = new Database();
$action = $_GET["action"] ?? "";

if ($action == "agendamentos") {
    $agendamentos = $db->getAgendamentos();
    echo json_encode($agendamentos);
} elseif ($action == "agendar" && $_SERVER["REQUEST_METHOD"] == "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    $nome = $data["nome"];
    $nascimento = $data["nascimento"];
    $tipo_eeg = $data["tipo_eeg"];
    $data_agendamento = $data["data"];
    $horario = $data["horario"];

    if ($db->isHorarioOcupado($data_agendamento, $horario)) {
        echo json_encode(["success" => false, "message" => "Horário já ocupado."]);
    } else {
        $result = $db->agendar($nome, $nascimento, $tipo_eeg, $data_agendamento, $horario);
        echo json_encode($result);
    }
} elseif ($action == "horarios_ocupados") {
    $horarios = $db->getHorariosOcupados();
    echo json_encode($horarios);
} else {
    echo json_encode(["error" => "Ação não especificada"]);
}
?>

