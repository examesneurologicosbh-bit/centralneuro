<?php
class Database {
    private $pdo;
    
    public function __construct() {
        try {
            $this->pdo = new PDO('sqlite:agendamentos.db');
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->createTables();
            $this->populateInitialData();
        } catch (PDOException $e) {
            die('Erro na conexão com o banco de dados: ' . $e->getMessage());
        }
    }
    
    private function createTables() {
        // Tabela original de agendamentos (modificada)
        $sql1 = "CREATE TABLE IF NOT EXISTS agendamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome_paciente TEXT NOT NULL,
            ano_nascimento INTEGER NOT NULL,
            tipo_eeg TEXT,
            categoria_exame TEXT NOT NULL,
            tipo_exame_id INTEGER NOT NULL,
            data_agendamento TEXT NOT NULL,
            horario TEXT NOT NULL,
            data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(categoria_exame, data_agendamento, horario)
        )";
        
        // Tabela de tipos de exames
        $sql2 = "CREATE TABLE IF NOT EXISTS tipos_exames (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            categoria TEXT NOT NULL,
            nome TEXT NOT NULL,
            valor DECIMAL(10,2) NOT NULL,
            ativo BOOLEAN DEFAULT 1
        )";
        
        // Tabela de horários por tipo
        $sql3 = "CREATE TABLE IF NOT EXISTS horarios_tipos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            categoria TEXT NOT NULL,
            dia_semana TEXT NOT NULL,
            horario TEXT NOT NULL,
            ativo BOOLEAN DEFAULT 1
        )";
        
        $this->pdo->exec($sql1);
        $this->pdo->exec($sql2);
        $this->pdo->exec($sql3);
    }
    
    private function populateInitialData() {
        // Verificar se já existem dados
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM tipos_exames");
        $stmt->execute();
        if ($stmt->fetchColumn() > 0) {
            return; // Dados já existem
        }
        
        // Inserir tipos de exames
        $tiposExames = [
            // EEG
            ['EEG', 'EEG Mapeamento', 240.00],
            ['EEG', 'EEG Rotina', 120.00],
            ['EEG', 'EEG Sono Vigília', 220.00],
            ['EEG', 'EEG Concurso', 200.00],
            ['EEG', 'EEG Infantil', 250.00],
            
            // ENMG
            ['ENMG', 'ENMG Membros Superiores', 180.00],
            ['ENMG', 'ENMG Membros Inferiores', 180.00],
            ['ENMG', 'ENMG Completo', 320.00],
            ['ENMG', 'ENMG Face', 150.00],
            
            // TC
            ['TC', 'TC Crânio', 280.00],
            ['TC', 'TC Tórax', 300.00],
            ['TC', 'TC Abdome', 320.00],
            ['TC', 'TC Coluna', 290.00],
            
            // RM
            ['RM', 'RM Crânio', 450.00],
            ['RM', 'RM Coluna', 480.00],
            ['RM', 'RM Joelho', 420.00],
            ['RM', 'RM Abdome', 500.00],
            
            // POLI
            ['POLI', 'Polissonografia Completa', 380.00],
            ['POLI', 'Polissonografia Reduzida', 280.00]
        ];
        
        $stmt = $this->pdo->prepare("INSERT INTO tipos_exames (categoria, nome, valor) VALUES (?, ?, ?)");
        foreach ($tiposExames as $tipo) {
            $stmt->execute($tipo);
        }
        
        // Inserir horários por categoria
        $horariosCategoria = [
            // EEG - Segunda a Sexta
            ['EEG', 'Monday', ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00']],
            ['EEG', 'Tuesday', ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00']],
            ['EEG', 'Wednesday', ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00']],
            ['EEG', 'Thursday', ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00']],
            ['EEG', 'Friday', ['08:00', '08:30', '13:00', '13:30', '14:00', '14:30', '15:00']],
            
            // ENMG - Segunda, Quarta, Sexta
            ['ENMG', 'Monday', ['08:00', '09:00', '10:00', '14:00', '15:00', '16:00']],
            ['ENMG', 'Wednesday', ['08:00', '09:00', '10:00', '14:00', '15:00', '16:00']],
            ['ENMG', 'Friday', ['08:00', '09:00', '10:00', '14:00', '15:00', '16:00']],
            
            // TC - Segunda a Quinta
            ['TC', 'Monday', ['07:00', '08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00']],
            ['TC', 'Tuesday', ['07:00', '08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00']],
            ['TC', 'Wednesday', ['07:00', '08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00']],
            ['TC', 'Thursday', ['07:00', '08:00', '09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00']],
            
            // RM - Terça, Quinta, Sábado
            ['RM', 'Tuesday', ['08:00', '09:30', '11:00', '14:00', '15:30', '17:00']],
            ['RM', 'Thursday', ['08:00', '09:30', '11:00', '14:00', '15:30', '17:00']],
            ['RM', 'Saturday', ['08:00', '09:30', '11:00', '14:00', '15:30', '17:00']],
            
            // POLI - Segunda, Quarta
            ['POLI', 'Monday', ['20:00', '21:00']],
            ['POLI', 'Wednesday', ['20:00', '21:00']]
        ];
        
        $stmt = $this->pdo->prepare("INSERT INTO horarios_tipos (categoria, dia_semana, horario) VALUES (?, ?, ?)");
        foreach ($horariosCategoria as $categoria) {
            $cat = $categoria[0];
            $dia = $categoria[1];
            $horarios = $categoria[2];
            
            foreach ($horarios as $horario) {
                $stmt->execute([$cat, $dia, $horario]);
            }
        }
    }
    
    public function getConnection() {
        return $this->pdo;
    }
    
    public function getCategorias() {
        $stmt = $this->pdo->prepare("SELECT DISTINCT categoria FROM tipos_exames WHERE ativo = 1 ORDER BY categoria");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    public function getTiposPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT id, nome, valor FROM tipos_exames WHERE categoria = ? AND ativo = 1 ORDER BY nome");
        $stmt->execute([$categoria]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getHorariosPorCategoria($categoria) {
        $stmt = $this->pdo->prepare("SELECT dia_semana, horario FROM horarios_tipos WHERE categoria = ? AND ativo = 1 ORDER BY dia_semana, horario");
        $stmt->execute([$categoria]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $horarios = [];
        foreach ($result as $row) {
            if (!isset($horarios[$row['dia_semana']])) {
                $horarios[$row['dia_semana']] = [];
            }
            $horarios[$row['dia_semana']][] = $row['horario'];
        }
        
        return $horarios;
    }
    
    public function getHorariosOcupados($categoria = null) {
        if ($categoria) {
            $stmt = $this->pdo->prepare("SELECT data_agendamento, horario FROM agendamentos WHERE categoria_exame = ?");
            $stmt->execute([$categoria]);
        } else {
            $stmt = $this->pdo->prepare("SELECT data_agendamento, horario, categoria_exame FROM agendamentos");
            $stmt->execute();
        }
        
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $horarios = [];
        foreach ($result as $row) {
            if ($categoria) {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'];
            } else {
                $horarios[] = $row['data_agendamento'] . ' ' . $row['horario'] . ' ' . $row['categoria_exame'];
            }
        }
        
        return $horarios;
    }
    
    public function agendarHorario($nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario) {
        try {
            // Buscar informações do tipo de exame
            $stmt = $this->pdo->prepare("SELECT nome, valor FROM tipos_exames WHERE id = ?");
            $stmt->execute([$tipoExameId]);
            $tipoExame = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$tipoExame) {
                return ['success' => false, 'message' => 'Tipo de exame não encontrado'];
            }
            
            $stmt = $this->pdo->prepare("INSERT INTO agendamentos (nome_paciente, ano_nascimento, categoria_exame, tipo_exame_id, data_agendamento, horario) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$nomePaciente, $anoNascimento, $categoriaExame, $tipoExameId, $dataAgendamento, $horario]);
            
            return [
                'success' => true, 
                'message' => 'Agendamento realizado com sucesso',
                'tipo_exame' => $tipoExame['nome'],
                'valor' => $tipoExame['valor']
            ];
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // UNIQUE constraint failed
                return ['success' => false, 'message' => 'Este horário já está ocupado para esta categoria'];
            }
            return ['success' => false, 'message' => 'Erro ao realizar agendamento: ' . $e->getMessage()];
        }
    }
    
    public function getAgendamentos($categoria = null) {
        if ($categoria) {
            $stmt = $this->pdo->prepare("
                SELECT a.*, te.nome as tipo_exame_nome, te.valor 
                FROM agendamentos a 
                JOIN tipos_exames te ON a.tipo_exame_id = te.id 
                WHERE a.categoria_exame = ? 
                ORDER BY a.data_agendamento, a.horario
            ");
            $stmt->execute([$categoria]);
        } else {
            $stmt = $this->pdo->prepare("
                SELECT a.*, te.nome as tipo_exame_nome, te.valor 
                FROM agendamentos a 
                JOIN tipos_exames te ON a.tipo_exame_id = te.id 
                ORDER BY a.data_agendamento, a.horario
            ");
            $stmt->execute();
        }
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

